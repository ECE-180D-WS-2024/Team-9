# Import standard libraries
import random
import sys
import time
import os

# Import GUI library
import pygame
from pygame.locals import (
    RLEACCEL, K_UP, K_DOWN, K_LEFT, K_RIGHT, K_ESCAPE,
    KEYDOWN, K_f, K_n, QUIT, K_s, K_m, K_2)

# Import libraries for computer vision
import cv2
import numpy as np

# Import libraries for asynchronous operations and web sockets
import asyncio
import websockets
import threading
from queue import Queue

# Import library for speech recognition
import speech_recognition as sr

# Initialize PyGame and mixer for sound effects
pygame.init()
pygame.mixer.init()  # Initialize the mixer module

# Screen and health bar constants
SCREEN_WIDTH = 1400
SCREEN_HEIGHT = 800
HEALTH_BAR_WIDTH = 600
HEALTH_BAR_HEIGHT = 25
HEALTH_BAR_OUTLINE_WIDTH = 5
HEALTH_BAR_OUTLINE_COLOR = (255, 0, 0)
HEALTH_BAR_POSITION = (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 50)

# Player health and ammo management
player_health = 100  # Initial player health
max_player_health = 100  # Maximum player health
max_shots = 5  # Maximum shots before needing a reload
current_shots = max_shots  # Current available shots
winner = ""

#multiplayer globals 
num_players = 0
score1 = 0
score2 = 0
score3 = 0
score4 = 0
current_shots1 = max_shots
current_shots2 = max_shots
current_shots3 = max_shots
current_shots4 = max_shots

# Sound effects
shoot_sound = pygame.mixer.Sound('shoot.mp3')
shoot_sound.set_volume(0.5)
enemy_dying_sound = pygame.mixer.Sound('enemyDying.mp3')
enemy_dying_sound.set_volume(1.0)
reload_sound = pygame.mixer.Sound('reload.mp3')
reload_sound.set_volume(1.0)
health_lost_sound = pygame.mixer.Sound('healthLoss.mp3')
health_lost_sound.set_volume(2.0)
no_ammo_sound = pygame.mixer.Sound('no_ammo.mp3')
no_ammo_sound.set_volume(1.0)

# Global variables
score = 0
command1 = ""
command_queue = Queue()  # Queue for command handling
recognizer = sr.Recognizer()  # For speech recognition
microphone = sr.Microphone()  # Microphone setup for speech recognition
player = None  # Placeholder for player object, to be defined in game logic
is_paused = False  # Flag to check if the game is paused
clock = pygame.time.Clock() # Setup for frame rate management
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT)) # Create the main game screen
default_font = pygame.font.Font(None, 36) # Font setup for drawing text
cap = cv2.VideoCapture(0) # Camera initialization for object localization

# Web Socket function
async def handle_websocket_commands(websocket, path):
    global command1  # Use command1 to store the most recent command
    async for message in websocket:
        command1 = message  # Update command1 with the received message

def start_websocket_server():
    global loop
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    start_server = websockets.serve(handle_websocket_commands, "0.0.0.0", 8765)
    loop.run_until_complete(start_server)
    loop.run_forever()

# Start the WebSocket server in a separate thread
websocket_thread = threading.Thread(target=start_websocket_server, name="WebSocketThread")
websocket_thread.start()

def recognize_speech_from_mic(recognizer, microphone):
    if not isinstance(recognizer, sr.Recognizer):     # Check that the recognizer and microphone arguments are appropriate types
        raise TypeError("`recognizer` must be `Recognizer` instance")   
    if not isinstance(microphone, sr.Microphone):
        raise TypeError("`microphone` must be `Microphone` instance")

    with microphone as source:
        recognizer.adjust_for_ambient_noise(source)  # Adjust for ambient noise
        print("Listening...")  # Signal to the user to start speaking
        try:
            audio = recognizer.listen(source, timeout=5)  # Listen for the first phrase
        except sr.WaitTimeoutError:  # Handling cases where no speech is detected within the timeout
            print("Listening timed out while waiting for speech")
            return ""  # Return an empty string to indicate failure

    try: # Recognize speech using Google Speech Recognition
        transcription = recognizer.recognize_google(audio)
        print(f"Transcription: {transcription}")  # Optional: Print the recognized text
        return transcription  # Return the recognized text
    except sr.RequestError:
        print("Speech Recognition service is unavailable") # API was unreachable or unresponsive
    except sr.UnknownValueError:
        print("Unable to recognize speech") # Speech was unintelligible
    return ""  # Return an empty string if recognition fails


def find_blue_object(frame):
    blurred_frame = cv2.GaussianBlur(frame, (5, 5), 0) # Apply Gaussian Blur to reduce noise and improve color detection
    hsv = cv2.cvtColor(blurred_frame, cv2.COLOR_BGR2HSV) # Convert the blurred frame to HSV color space
    lower_blue = np.array([90, 100, 100]) # Adjust the range for blue color to be more inclusive and robust
    upper_blue = np.array([150, 255, 255])
    mask = cv2.inRange(hsv, lower_blue, upper_blue) # Threshold the HSV image to get only blue colors
    kernel = np.ones((5, 5), np.uint8)  # Apply additional morphological operations like opening to remove small objects or noise
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE) # Find contours in the mask
    filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 500]  # Adjust 500 to your specific needs

    if filtered_contours: # Proceed only if at least one contour was found
        largest_contour = max(filtered_contours, key=cv2.contourArea)  # Find the largest contour among the filtered ones, assuming it's the blue object
        x, y, w, h = cv2.boundingRect(largest_contour)
        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2) # Draw a bounding box around the largest contour
        centroid_blue = (x + w // 2, y + h // 2)
        return centroid_blue

    return None

def find_red_object(frame):
    blurred_frame = cv2.GaussianBlur(frame, (5, 5), 0)  # Apply Gaussian Blur to reduce noise and improve color detection
    hsv = cv2.cvtColor(blurred_frame, cv2.COLOR_BGR2HSV) # Convert the blurred frame to HSV color space
    lower_red1 = np.array([0, 100, 100]) # Low range of red
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([160, 100, 100]) # High range of red
    upper_red2 = np.array([180, 255, 255])
    mask1 = cv2.inRange(hsv, lower_red1, upper_red1) # Threshold the HSV image to get only red colors
    mask2 = cv2.inRange(hsv, lower_red2, upper_red2)
    red_mask = cv2.bitwise_or(mask1, mask2)
    kernel = np.ones((5, 5), np.uint8)  # Apply additional morphological operations like opening to remove small objects or noise
    red_mask = cv2.morphologyEx(red_mask, cv2.MORPH_OPEN, kernel)
    contours, _ = cv2.findContours(red_mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE) # Find contours in the mask
    filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 500]  # Adjust 500 to your specific needs

    if filtered_contours: # Proceed only if at least one contour was found
        largest_contour = max(filtered_contours, key=cv2.contourArea) # Find the largest contour among the filtered ones, assuming it's the red object
        x, y, w, h = cv2.boundingRect(largest_contour)
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 0, 255), 2) # Draw a bounding box around the largest contour
        centroid_red = (x + w // 2, y + h // 2)
        return centroid_red

    return None

def find_green_object(frame):
    blurred_frame = cv2.GaussianBlur(frame, (5, 5), 0)
    hsv = cv2.cvtColor(blurred_frame, cv2.COLOR_BGR2HSV)
    lower_green = np.array([40, 100, 100]) # Adjust the lower range based on your specific green color
    upper_green = np.array([80, 255, 255]) # Adjust the upper range based on your specific green color
    mask = cv2.inRange(hsv, lower_green, upper_green)
    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 500]

    if filtered_contours:
        largest_contour = max(filtered_contours, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(largest_contour)
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        centroid_green = (x + w // 2, y + h // 2)
        return centroid_green

    return None

def find_yellow_object(frame):
    blurred_frame = cv2.GaussianBlur(frame, (5, 5), 0)
    hsv = cv2.cvtColor(blurred_frame, cv2.COLOR_BGR2HSV)
    lower_yellow = np.array([20, 100, 100]) # Adjust the lower range based on your specific yellow color
    upper_yellow = np.array([40, 255, 255]) # Adjust the upper range based on your specific yellow color
    mask = cv2.inRange(hsv, lower_yellow, upper_yellow)
    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 500]

    if filtered_contours:
        largest_contour = max(filtered_contours, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(largest_contour)
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 255), 2)
        centroid_yellow = (x + w // 2, y + h // 2)
        return centroid_yellow
 
    return None

def draw_text(text, position, font_size=36, color=(255, 0, 0), highlight_color=(50, 50, 50)):
    font = pygame.font.Font(None, font_size) # Set up the font with the specified font size
    text_surface = font.render(text, True, color) # Create the main text surface in red
    text_rect = text_surface.get_rect(center=position)
    highlight_surface = font.render(text, True, highlight_color) # Create a 'highlight' or 'shadow' for the text in dark grey, slightly offset
    highlight_rect = highlight_surface.get_rect(center=(position[0]+2, position[1]+2))  # Adjust the offset values as needed
    screen.blit(highlight_surface, highlight_rect) # Blit the highlight first, then the main text on top
    screen.blit(text_surface, text_rect)

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super(Player, self).__init__()
        self.surf = pygame.image.load("crosshair.png").convert_alpha() # Load the image with transparency preserved
        self.surf = pygame.transform.scale(self.surf, (100, 100)) # Scale the image to the desired size
        self.rect = self.surf.get_rect()

    def update(self):
        ret, frame = cap.read() # Capture the current frame
        if not ret:
            return  # If frame not captured successfully, skip this iteration
        centroid_blue = find_blue_object(frame) # Find the blue object in the frame
        if centroid_blue:
            inverted_x = frame.shape[1] - centroid_blue[0] # Invert the x-coordinate movement
            self.rect.center = (inverted_x * SCREEN_WIDTH // frame.shape[1], centroid_blue[1] * SCREEN_HEIGHT // frame.shape[0])  # Adjust the player's position on screen based on the inverted x-coordinate
        cv2.imshow("Camera Output", frame) # Display the frame in a separate OpenCV window
        cv2.waitKey(1)  # Refresh the display window at short intervals

class Player_2(pygame.sprite.Sprite):
    def __init__(self):
        super(Player_2, self).__init__()
        self.surf = pygame.image.load("crosshair_red.png").convert_alpha() # Load the image with transparency preserved, but use the red crosshair image
        self.surf = pygame.transform.scale(self.surf, (100, 100)) # Scale the image to the desired size
        self.rect = self.surf.get_rect()

    def update(self):
        ret, frame = cap.read() # Capture the current frame
        if not ret:
            return  # If frame not captured successfully, skip this iteration
        centroid_red = find_red_object(frame) # Find the red object in the frame
        if centroid_red:
            inverted_x = frame.shape[1] - centroid_red[0] # Invert the x-coordinate movement
            self.rect.center = (inverted_x * SCREEN_WIDTH // frame.shape[1], centroid_red[1] * SCREEN_HEIGHT // frame.shape[0]) # Adjust the player's position on screen based on the inverted x-coordinate
        cv2.imshow("Camera Output", frame) # Display the frame in a separate OpenCV window
        cv2.waitKey(1)  # Refresh the display window at short intervals

class Player_3(pygame.sprite.Sprite):
    def __init__(self):
        super(Player_3, self).__init__()
        self.surf = pygame.image.load("crosshair_green.png").convert_alpha()  # Load the green crosshair image with transparency
        self.surf = pygame.transform.scale(self.surf, (100, 100))  # Scale the image to the desired size
        self.rect = self.surf.get_rect()

    def update(self):
        ret, frame = cap.read()  # Capture the current frame
        if not ret:
            return  # If frame not captured successfully, skip this iteration
        centroid_green = find_green_object(frame)  # Find the green object in the frame
        if centroid_green:
            inverted_x = frame.shape[1] - centroid_green[0]  # Invert the x-coordinate movement
            self.rect.center = (inverted_x * SCREEN_WIDTH // frame.shape[1], centroid_green[1] * SCREEN_HEIGHT // frame.shape[0])  # Adjust the player's position on screen
        cv2.imshow("Camera Output", frame)  # Display the frame in a separate OpenCV window
        cv2.waitKey(1)  # Refresh the display window at short intervals

class Player_4(pygame.sprite.Sprite):
    def __init__(self):
        super(Player_4, self).__init__()
        self.surf = pygame.image.load("crosshair_yellow.png").convert_alpha()  # Load the yellow crosshair image with transparency
        self.surf = pygame.transform.scale(self.surf, (100, 100))  # Scale the image to the desired size
        self.rect = self.surf.get_rect()

    def update(self):
        ret, frame = cap.read()  # Capture the current frame
        if not ret:
            return  # If frame not captured successfully, skip this iteration
        centroid_yellow = find_yellow_object(frame)  # Find the yellow object in the frame
        if centroid_yellow:
            inverted_x = frame.shape[1] - centroid_yellow[0]  # Invert the x-coordinate movement
            self.rect.center = (inverted_x * SCREEN_WIDTH // frame.shape[1], centroid_yellow[1] * SCREEN_HEIGHT // frame.shape[0])  # Adjust the player's position on screen
        cv2.imshow("Camera Output", frame)  # Display the frame in a separate OpenCV window
        cv2.waitKey(1)  # Refresh the display window at short intervals

class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super(Enemy, self).__init__()
        self.original_surf = pygame.image.load("enemy.png").convert_alpha()  # Load the image, ensuring the use of the alpha channel for transparency
        self.surf = pygame.transform.scale(self.original_surf, (200, 200)) # Scale the image to the desired size (e.g., 50x50 pixels)
        self.rect = self.surf.get_rect(
            center=(
                random.randint(SCREEN_WIDTH + 20, SCREEN_WIDTH + 100),
                random.randint(0, SCREEN_HEIGHT),
            )
        )
        self.speed = random.randint(5, 10)

    def update(self):
        self.rect.move_ip(-self.speed, 0)
        if self.rect.right < 0:
            global player_health
            player_health -= 10  # Decrease health by 10%
            if player_health <= 0:
                player_health = 0  # Ensure health doesn't go below 0
            self.kill()

def quit_game():
    global websocket_thread, loop  # Make sure to declare these as global at the point of their creation

    if loop.is_running(): # Check if the WebSocket server's event loop is running and stop it
        loop.call_soon_threadsafe(loop.stop)  # Gracefully stop the loop
        while loop.is_running():
            time.sleep(0.1)  # Wait a bit for the event loop to stop
    loop.close() # Close the loop after stopping it

    if websocket_thread.is_alive(): # Ensure the WebSocket thread is joined
        websocket_thread.join()    

    cap.release()  # Release the camera
    cv2.destroyAllWindows()  # Close all OpenCV windows
    pygame.quit()  # Quit pygame
    sys.exit()  # Exit the script

def pause_menu():
    global mic_available  # Assuming mic_available is declared globally at the top of your script
    mic_available = True  # Ensure the microphone is available when entering the pause menu
    pygame.mixer.music.pause()  # Pause the in-game music
    paused = True
   
    while paused:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:  # Return to main menu
                    paused = False
                    main_menu()  # This will handle playing the main menu music
                elif event.key == pygame.K_p:  # Resume the game
                    pygame.mixer.music.unpause()  # Unpause the in-game music
                    paused = False
                elif event.key == pygame.K_m and mic_available:
                    mic_available = False  # Temporarily disable the microphone to prevent re-entry
                    speech_command = recognize_speech_from_mic(recognizer, microphone) # Activate the microphone and listen for speech
                    if speech_command.lower() == "main menu":
                        paused = False
                        main_menu()  # Return to the main menu
                    elif speech_command.lower() == "resume":
                        pygame.mixer.music.unpause()  # Unpause the in-game music
                        paused = False                   
                    mic_available = True  # Re-enable the microphone after processing                   
            elif event.type == pygame.QUIT:
                quit_game()

        screen.fill((0, 0, 0))
        draw_text("PAUSED", (SCREEN_WIDTH/2, SCREEN_HEIGHT/8), font_size=120)
        draw_text("MAIN MENU (ESC)", (SCREEN_WIDTH/2, SCREEN_HEIGHT/2.5), font_size=80)
        draw_text("RESUME (P)", (SCREEN_WIDTH/2, SCREEN_HEIGHT/2), font_size=80)

        pygame.display.flip()
        clock.tick(30)

def settings_menu():
    global mic_available  # Ensure this is declared at the top of your script
    mic_available = True  # Make sure the microphone is available when entering settings

    in_settings = True
    while in_settings:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:  # Return to main menu
                    in_settings = False
                elif event.key == pygame.K_m and mic_available:
                    mic_available = False # Prevent further activation until this cycle is complete
                    speech_command = recognize_speech_from_mic(recognizer, microphone) # Activate the microphone and listen for speech
                    if speech_command.lower() == "main menu":
                        in_settings = False  # Exit the settings menu
                    mic_available = True  # After processing the command, allow microphone activation again
            elif event.type == pygame.QUIT:
                quit_game()

        screen.fill((0, 0, 0))
        draw_text("SETTINGS", (SCREEN_WIDTH/2, SCREEN_HEIGHT/8), font_size=120)
        draw_text("MAIN MENU (ESC)", (SCREEN_WIDTH/2, SCREEN_HEIGHT/2.5), font_size=80)

        pygame.display.flip()
        clock.tick(30)

def select_number_of_players_menu():
    global num_players, mic_available
    menu_running = True
    mic_available = True

    while menu_running:
        screen.fill((0, 0, 0))  # Clear screen with black

        # Title
        draw_text('Select Number of Players', (screen.get_width() / 2, screen.get_height() / 5), font_size=48, color=(255, 255, 255), highlight_color=(50, 50, 50))

        # Options
        options_start_y = screen.get_height() / 3
        row_height = 50  # Adjust for spacing between options
        draw_text('2 Players (Press 2)', (screen.get_width() / 2, options_start_y + row_height * 1), font_size=36, color=(255, 255, 255), highlight_color=(50, 50, 50))
        draw_text('3 Players (Press 3)', (screen.get_width() / 2, options_start_y + row_height * 2), font_size=36, color=(255, 255, 255), highlight_color=(50, 50, 50))
        draw_text('4 Players (Press 4)', (screen.get_width() / 2, options_start_y + row_height * 3), font_size=36, color=(255, 255, 255), highlight_color=(50, 50, 50))
        draw_text('Main Menu (Press ESC)', (screen.get_width() / 2, options_start_y + row_height * 4), font_size=36, color=(255, 255, 255), highlight_color=(50, 50, 50))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_2:
                    num_players = 2
                    menu_running = False
                elif event.key == pygame.K_3:
                    num_players = 3
                    menu_running = False
                elif event.key == pygame.K_4:
                    num_players = 4
                    menu_running = False
                elif event.key == pygame.K_ESCAPE:
                    # Return to main menu
                    main_menu()
                    menu_running = False
                elif event.key == pygame.K_m and mic_available:
                    mic_available = False  # Temporarily disable the microphone to prevent re-entry
                    speech_command = recognize_speech_from_mic(recognizer, microphone) # Activate the microphone and listen for speech
                    if speech_command.lower() == "two":
                        num_players = 2
                        menu_running = False
                    elif speech_command.lower() == "three":
                        num_players = 3
                        menu_running = False
                    elif speech_command.lower() == "four":
                        num_players = 4
                        menu_running = False
                    elif speech_command.lower() == "main menu":
                        main_menu()
                        menu_running = False 
                    mic_available = True

        clock.tick(30)

    return num_players


def game_loop(restart=False):
   global player_health, score, current_shots, max_shots, enemies, all_sprites, running, mic_available, command1 

   player = Player()
   multiplier = 100
   
   if restart: # Reset necessary variables for a new game
        player_health = 100  # Reset player's health
        score = 0  # Reset score
        current_shots = max_shots  # Reset ammunition
        enemies.empty()  # Remove all enemy sprites
        all_sprites.empty()  # Remove all sprites
        all_sprites.add(player)  # Add the player sprite back
        pygame.mixer.music.load('in_game_music.mp3')  # Reload in-game music
        pygame.mixer.music.set_volume(0.2)
        pygame.mixer.music.play(-1)

   if not restart: # Play in-game music only if not restarting the game
        pygame.mixer.music.load('in_game_music.mp3')
        pygame.mixer.music.set_volume(0.2)  # music volume
        pygame.mixer.music.play(-1)  # Play the music indefinitely

   background = pygame.image.load("background.png").convert()
   background = pygame.transform.scale(background, (1900, 1000))

   enemies = pygame.sprite.Group()
   all_sprites = pygame.sprite.Group()
   all_sprites.add(player)

   ADDENEMY = pygame.USEREVENT + 1
   spawn_interval = 2500  # Adjust this value as needed to decrease spawn frequency
   score = 0
   running = True
   game_start_time = pygame.time.get_ticks()
   spawn_delay_passed = False
   mic_available = True

   while running:
        current_time = pygame.time.get_ticks()
        if not spawn_delay_passed and current_time - game_start_time > 2000: # Ten sec delay when starting the game
            pygame.time.set_timer(ADDENEMY, spawn_interval)
            spawn_delay_passed = True

        if is_paused:
            pause_menu()  # Display the pause menu
            continue  # Skip the rest of the game loop

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pause_menu()
                elif event.key == pygame.K_UP: # UNCOMMENT TO TEST GAME OVER SCREEN
                    running = False
                    game_over_screen(score)
                '''elif event.type == pygame.KEYDOWN and event.key == pygame.K_m and mic_available:
                    mic_available = False  # Prevent multiple activations
                    speech_command = recognize_speech_from_mic(recognizer, microphone) # Activate the microphone and listen for speech
                    if speech_command.lower() == "stop":
                        pause_menu()  # Call your pause menu
                        pygame.mixer.music.unpause()  # Ensure music playback resumes if coming back from pause
                mic_available = True  # Re-enable microphone after processing '''   
            elif event.type == pygame.QUIT:
                running = False
            elif event.type == ADDENEMY and spawn_delay_passed:
                new_enemy = Enemy()
                enemies.add(new_enemy)
                all_sprites.add(new_enemy)

        if command1 == "shoot": # Process the most recent command received via WebSocket
            if current_shots > 0:
                shoot_sound.play()
                killed_enemies = pygame.sprite.spritecollide(player, enemies, dokill=True)
                if killed_enemies:
                    score += multiplier * len(killed_enemies)  # Update the score
                current_shots -= 1
                command1 = ""  # Reset command1 after processing
            else:
                no_ammo_sound.play()
                command1 = ""  # Reset command1 if there's no ammo
        elif command1 == "reload":
            reload_sound.play()
            current_shots = max_shots  # Reset to maximum shots
            command1 = ""  # Reset command1 after processing
        elif command1 == "powerup_doublepts":
            multiplier = 200
            command1 = ""  # Reset command1 after processing
        elif command1 == "powerup_nuke":
            num_enemies_eliminated = len(enemies)  # Count the number of enemies before eliminating them
            for enemy in list(enemies):  # Ensure to iterate over a copy of the group list
                all_sprites.remove(enemy)  # Remove each enemy from the all_sprites group for rendering purposes
                enemies.remove(enemy)  # Also remove from enemies group to ensure it's cleared from logic handling
            score += 100 * num_enemies_eliminated  # Award 100 points for each enemy eliminated by the nuke
            command1 = ""  # Reset command1 after processing to avoid repeatedly triggering the nuke      

        player.update()

        for enemy in enemies:
            enemy.update()
            if enemy.rect.right < 0:  # Enemy has passed the left edge
                health_lost_sound.play()
                enemy.kill()
                player_health -= 10  # Decrease health by 10%

        if player_health <= 0: # Check player health after updating all enemies
            game_over_screen(score)  # Call game over screen when health depletes
            break  # Exit the game loop

        screen.blit(background, (0, 0))
        draw_health_bar(screen, player_health, HEALTH_BAR_POSITION)
        for entity in all_sprites:
            screen.blit(entity.surf, entity.rect)

        draw_text("WALL HEALTH", (HEALTH_BAR_POSITION[0], HEALTH_BAR_POSITION[1] - 40), font_size=60)
        mag_text = f"BLASTS: {current_shots}/{max_shots}"
        draw_text(mag_text, (SCREEN_WIDTH - 220, SCREEN_HEIGHT - 30), font_size=60)
        draw_text(f"SCORE: {score}", (SCREEN_WIDTH * 0.5, SCREEN_HEIGHT * 0.05), font_size=80)

        pygame.display.flip()
        clock.tick(30)

def multiplayer(num_players, restart=False):
    global player_health, score1, score2, score3, score4, current_shots1, current_shots2, current_shots3, current_shots4, max_shots, all_sprites, running, mic_available, command1
    multiplier1 = multiplier2 = multiplier3 = multiplier4 = 100

    # Initialize player instances
    blue_player = Player()
    red_player = Player_2()
    green_player = Player_3() if num_players >= 3 else None
    yellow_player = Player_4() if num_players == 4 else None
    winner = "none"

    if restart:
        winner = "None"
        player_health = 100
        score1 = score2 = score3 = score4 = 0
        current_shots1 = current_shots2 = current_shots3 = current_shots4 = max_shots
        all_sprites.empty()
        pygame.mixer.music.load('in_game_music.mp3')
        pygame.mixer.music.set_volume(0.2)
        pygame.mixer.music.play(-1)

    if not restart:
        pygame.mixer.music.load('in_game_music.mp3')
        pygame.mixer.music.set_volume(0.2)
        pygame.mixer.music.play(-1)

    background = pygame.image.load("background.png").convert()
    background = pygame.transform.scale(background, (1400, 800))
    enemies = pygame.sprite.Group()
    all_sprites = pygame.sprite.Group()
    all_sprites.add(blue_player, red_player)
    if green_player:
        all_sprites.add(green_player)
    if yellow_player:
        all_sprites.add(yellow_player)
    ADDENEMY = pygame.USEREVENT + 1
    spawn_interval = 2500  # Adjust this value as needed to decrease spawn frequency
    score1 = 0
    score2 = 0
    running = True
    game_start_time = pygame.time.get_ticks()
    spawn_delay_passed = False
    mic_available = True
    
    while running:
        current_time = pygame.time.get_ticks()
        if not spawn_delay_passed and current_time - game_start_time > 2000: # Ten sec delay when starting the game
            pygame.time.set_timer(ADDENEMY, spawn_interval)
            spawn_delay_passed = True

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pause_menu()  # Assuming pause_menu is implemented
                elif event.key == pygame.K_UP: # UNCOMMENT TO TEST GAME OVER SCREEN
                   running = False
                   game_over_screen_multiplayer(score1, score2, winner)
                '''elif event.type == pygame.KEYDOWN and event.key == pygame.K_m and mic_available:
                    mic_available = False  # Prevent multiple activations
                    speech_command = recognize_speech_from_mic(recognizer, microphone) # Activate the microphone and listen for speech
                    if speech_command.lower() == "stop":
                        pause_menu()  # Call your pause menu
                        pygame.mixer.music.unpause()  # Ensure music playback resumes if coming back from pause
                mic_available = True  # Re-enable microphone after processing'''
            elif event.type == ADDENEMY and spawn_delay_passed:
                new_enemy = Enemy()
                enemies.add(new_enemy)
                all_sprites.add(new_enemy)
            elif event.type == pygame.QUIT:
                running = False

        if command1 == "shoot":
            if current_shots1 > 0:
                shoot_sound.play()
                killed_enemies = pygame.sprite.spritecollide(blue_player, enemies, dokill=True)
                if killed_enemies:
                    score1 += multiplier1 * len(killed_enemies)  # Update the score
                current_shots1 -= 1
                command1 = ""  # Reset command1 after processing
            else:
                no_ammo_sound.play()
                command1 = ""  # Reset command1 if there's no ammo
        elif command1 == "reload":
            reload_sound.play()
            current_shots1 = max_shots  # Reset to maximum shots
            command1 = ""  # Reset command1 after processing
        elif command1 == "powerup_doublepts":
            multiplier1 = 200
            command1 = ""  # Reset command1 after processing
        elif command1 == "powerup_nuke":
            num_enemies_eliminated = len(enemies)  # Count the number of enemies before eliminating them
            for enemy in list(enemies):  # Ensure to iterate over a copy of the group list
                all_sprites.remove(enemy)  # Remove each enemy from the all_sprites group for rendering purposes
                enemies.remove(enemy)  # Also remove from enemies group to ensure it's cleared from logic handling
            score1 += 100 * num_enemies_eliminated  # Award 100 points for each enemy eliminated by the nuke
            command1 = ""  # Reset command1 after processing to avoid repeatedly triggering the nuke      
        
        elif command1 == "shoot2":
            if current_shots2 > 0:
                shoot_sound.play()
                killed_enemies = pygame.sprite.spritecollide(red_player, enemies, dokill=True)
                if killed_enemies:
                    score2 += multiplier2 * len(killed_enemies)  # Update the score
                current_shots2 -= 1
                command1 = ""  # Reset command1 after processing
            else:
                no_ammo_sound.play()
                command1 = ""  # Reset command1 if there's no ammo
        elif command1 == "reload2":
            reload_sound.play()
            current_shots2 = max_shots  # Reset to maximum shots
            command1 = ""  # Reset command1 after processing
        elif command1 == "powerup_doublepts2":
            multiplier2 = 200
            command1 = ""  # Reset command1 after processing
        elif command1 == "powerup_nuke2":
            num_enemies_eliminated = len(enemies)  # Count the number of enemies before eliminating them
            for enemy in list(enemies):  # Ensure to iterate over a copy of the group list
                all_sprites.remove(enemy)  # Remove each enemy from the all_sprites group for rendering purposes
                enemies.remove(enemy)  # Also remove from enemies group to ensure it's cleared from logic handling
            score2 += 100 * num_enemies_eliminated  # Award 100 points for each enemy eliminated by the nuke
            command1 = ""  # Reset command1 after processing to avoid repeatedly triggering the nuke      
       
        elif command1 == "shoot3":
            if current_shots3 > 0:
                shoot_sound.play()
                killed_enemies = pygame.sprite.spritecollide(green_player, enemies, dokill=True)
                if killed_enemies:
                    score3 += multiplier3 * len(killed_enemies)  # Update the score
                current_shots3 -= 1
                command1 = ""  # Reset command1 after processing
            else:
                no_ammo_sound.play()
                command1 = ""  # Reset command1 if there's no ammo
        elif command1 == "reload3":
            reload_sound.play()
            current_shots3 = max_shots  # Reset to maximum shots
            command1 = ""  # Reset command1 after processing
        elif command1 == "powerup_doublepts":
            multiplier3 = 200
            command1 = ""  # Reset command1 after processing
        elif command1 == "powerup_nuke":
            num_enemies_eliminated = len(enemies)  # Count the number of enemies before eliminating them
            for enemy in list(enemies):  # Ensure to iterate over a copy of the group list
                all_sprites.remove(enemy)  # Remove each enemy from the all_sprites group for rendering purposes
                enemies.remove(enemy)  # Also remove from enemies group to ensure it's cleared from logic handling
            score3 += 100 * num_enemies_eliminated  # Award 100 points for each enemy eliminated by the nuke
            command1 = ""  # Reset command1 after processing to avoid repeatedly triggering the nuke      

        
        elif command1 == "shoot4":
            if current_shots4 > 0:
                shoot_sound.play()
                killed_enemies = pygame.sprite.spritecollide(yellow_player, enemies, dokill=True)
                if killed_enemies:
                    score4 += multiplier4 * len(killed_enemies)  # Update the score
                current_shots4 -= 1
                command1 = ""  # Reset command1 after processing
            else:
                no_ammo_sound.play()
                command1 = ""  # Reset command1 if there's no ammo
        elif command1 == "reload4":
            reload_sound.play()
            current_shots4 = max_shots  # Reset to maximum shots
            command1 = ""  # Reset command1 after processing        
        elif command1 == "powerup_doublepts":
            multiplier4 = 200
            command1 = ""  # Reset command1 after processing
        elif command1 == "powerup_nuke":
            num_enemies_eliminated = len(enemies)  # Count the number of enemies before eliminating them
            for enemy in list(enemies):  # Ensure to iterate over a copy of the group list
                all_sprites.remove(enemy)  # Remove each enemy from the all_sprites group for rendering purposes
                enemies.remove(enemy)  # Also remove from enemies group to ensure it's cleared from logic handling
            score4 += 100 * num_enemies_eliminated  # Award 100 points for each enemy eliminated by the nuke
            command1 = ""  # Reset command1 after processing to avoid repeatedly triggering the nuke      


        blue_player.update()
        red_player.update()
        if green_player:  # Check if green_player is not None
            green_player.update()
        if yellow_player:  # Check if yellow_player is not None
            yellow_player.update()
        
        # Initial assumption about the winner
        winner = "blue"
        highest_score = score1

        # Compare with second player's score
        if score2 > highest_score:
            winner = "red"
            highest_score = score2

        # If there's a green player and their score is higher, update the winner to green
        if green_player and score3 > highest_score:
            winner = "green"
            highest_score = score3

        # Finally, if there's a yellow player and their score is the highest, update the winner to yellow
        if yellow_player and score4 > highest_score:
            winner = "yellow"
            highest_score = score4

        for enemy in enemies:
            enemy.update()
            if enemy.rect.right < 0:  # Enemy has passed the left edge
                health_lost_sound.play()
                enemy.kill()
                player_health -= 10  # Decrease health by 10%

        if player_health <= 0: # Check player health after updating all enemies      
            game_over_screen_multiplayer(score1, score2, winner)  # Call game over screen when health depletes
            break  # Exit the game loop

        screen.blit(background, (0, 0))
        draw_health_bar(screen, player_health, HEALTH_BAR_POSITION)
        for entity in all_sprites:
            screen.blit(entity.surf, entity.rect)

        draw_text("WALL HEALTH", (HEALTH_BAR_POSITION[0], HEALTH_BAR_POSITION[1] - 40), font_size=60)
        draw_text(f"Score1: {score1}", (70, screen.get_height() - 50), font_size=30)
        draw_text(f"Score2: {score2}", (screen.get_width() - 70, screen.get_height() - 50), font_size=30)
        draw_text(f"Blasts1: {current_shots1}", (70, 20), font_size=30)
        draw_text(f"Blasts2: {current_shots2}", (screen.get_width() - 70, 20), font_size=30)

        # If the green player exists, display their score and blasts above the first player's info
        if green_player:
            draw_text(f"Score3: {score3}", (70, screen.get_height() - 80), font_size=30)  # Adjusted position
            draw_text(f"Blasts3: {current_shots3}", (70, 0), font_size=30)  # Adjusted position

        # If the yellow player exists, display their score and blasts above the second player's info
        if yellow_player:
            draw_text(f"Score4: {score4}", (screen.get_width() - 70, screen.get_height() - 80), font_size=30)  # Adjusted position
            draw_text(f"Blasts4: {current_shots4}", (screen.get_width() - 70, 0), font_size=30)  # Adjusted position

        pygame.display.flip()
        clock.tick(30)

def draw_health_bar(screen, health, position):
    health_bar_x = position[0] - (HEALTH_BAR_WIDTH // 2) # Define the position and size of the health bar
    health_bar_y = position[1]
    health_bar_filled_width = int((health / max_player_health) * HEALTH_BAR_WIDTH)
    outline_rect = pygame.Rect(health_bar_x, health_bar_y, HEALTH_BAR_WIDTH, HEALTH_BAR_HEIGHT) # Draw the health bar outline
    pygame.draw.rect(screen, HEALTH_BAR_OUTLINE_COLOR, outline_rect, HEALTH_BAR_OUTLINE_WIDTH)
    filled_rect = pygame.Rect(health_bar_x, health_bar_y, health_bar_filled_width, HEALTH_BAR_HEIGHT) # Draw the filled part of the health bar
    pygame.draw.rect(screen, (255, 0, 0), filled_rect)

def game_over_screen(score):
    global mic_available  # Ensure mic_available is declared globally at the top of your script
    mic_available = True  # Ensure the microphone is available when entering the game over screen

    while True:  # Using 'True' for clarity
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    game_loop(restart=True)  # Restart the game
                    return  # Exit the game over screen after restarting the game
                elif event.key == pygame.K_ESCAPE:
                    main_menu()  # Return to the main menu
                    return  # Exit the game over screen after going to the main menu
                elif event.key == pygame.K_m and mic_available:
                    mic_available = False  # Temporarily disable the microphone to prevent re-entry

                    # Activate the microphone and listen for speech
                    speech_command = recognize_speech_from_mic(recognizer, microphone)
                    if speech_command.lower() == "play again":
                        game_loop(restart=True)  # Restart the game
                        return  # Exit the game over screen after restarting the game
                    elif speech_command.lower() == "main menu":
                        main_menu()  # Return to the main menu
                        return  # Exit the game over screen after going to the main menu

                    mic_available = True  # Re-enable the microphone after processing

            elif event.type == pygame.QUIT:
                quit_game()

        screen.fill((0, 0, 0))  # Clear the screen
        draw_text("GAME OVER", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 8), font_size=120, color=(255, 0, 0))
        draw_text(f"YOUR SCORE: {score}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 4), font_size=120)
        draw_text("PLAY AGAIN (P)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.3), font_size=80)
        draw_text("MAIN MENU (ESC)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2), font_size=80)

        pygame.display.flip()  # Update the screen
        clock.tick(30)  # Maintain a steady framerate

def game_over_screen_multiplayer(score1, score2, winner):
    global num_players, mic_available  # Ensure mic_available is declared globally at the top of your script
    mic_available = True  # Ensure the microphone is available when entering the game over screen

    while True:  # Using 'True' for clarity
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    multiplayer(num_players, restart=True)  # Restart the game
                    return  # Exit the game over screen after restarting the game
                elif event.key == pygame.K_ESCAPE:
                    main_menu()  # Return to the main menu
                    return  # Exit the game over screen after going to the main menu
                elif event.key == pygame.K_m and mic_available:
                    mic_available = False  # Temporarily disable the microphone to prevent re-entry
                    speech_command = recognize_speech_from_mic(recognizer, microphone) # Activate the microphone and listen for speech
                    if speech_command.lower() == "play again":
                        multiplayer(num_players, restart=True)  # Restart the game
                        return  # Exit the game over screen after restarting the game
                    elif speech_command.lower() == "main menu":
                        main_menu()  # Return to the main menu
                        return  # Exit the game over screen after going to the main menu
                    mic_available = True  # Re-enable the microphone after processing
            elif event.type == pygame.QUIT:
                quit_game()

        screen.fill((0, 0, 0))  # Clear the screen
        draw_text("GAME OVER", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 8), font_size=120, color=(255, 0, 0))
        draw_text(f"PLAYER 1 SCORE: {score1}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 3.5), font_size=120)
        draw_text(f"PLAYER 2 SCORE: {score2}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.5), font_size=120)
        draw_text(f"Winner: {winner}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 1.9), font_size=120)
        draw_text("PLAY AGAIN (P)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 1.6), font_size=80)
        draw_text("MAIN MENU (ESC)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 1.4), font_size=80)

        pygame.display.flip()  # Update the screen
        clock.tick(30)  # Maintain a steady framerate

def main_menu():
    main_menu_background = pygame.image.load("main_menu_background.png").convert()
    main_menu_background = pygame.transform.scale(main_menu_background, (SCREEN_WIDTH, SCREEN_HEIGHT))

    pygame.mixer.music.load('main_menu_music.mp3')
    pygame.mixer.music.play(-1)

    menu_running = True
    while menu_running:
        screen.blit(main_menu_background, (0, 0))
        draw_text("RAILGUN RAMPAGE", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 10), font_size=140)  # Adjusted for better vertical positioning
        draw_text("PLAY (P)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.7 + 60), font_size=80)  # Added offset for even spacing
        draw_text("MULTIPLAYER (2)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.7 + 120), font_size=80)  # Adjusted spacing
        draw_text("SETTINGS (S)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.7 + 180), font_size=80)  # Adjusted spacing
        draw_text("QUIT (ESC)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.7 + 240), font_size=80)  # Adjusted spacing for quit option
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    pygame.mixer.music.stop()
                    game_loop()
                    pygame.mixer.music.play(-1)
                elif event.key == pygame.K_2:  # Detecting '2' key for multiplayer
                    pygame.mixer.music.stop()
                    num_players = select_number_of_players_menu()  # Get the number of players
                    multiplayer(num_players)  # Call multiplayer function which then goes to pause menu
                    pygame.mixer.music.play(-1)    
                elif event.key == pygame.K_s:
                    settings_menu()
                elif event.key == pygame.K_m:
                    speech_command = recognize_speech_from_mic(recognizer, microphone) # Activate the microphone and listen for speech
                    if speech_command.lower() == "play":
                        pygame.mixer.music.stop()
                        game_loop()
                        pygame.mixer.music.play(-1)
                    elif speech_command.lower() == "multiplayer":
                        pygame.mixer.music.stop()
                        select_number_of_players_menu()
                        pygame.mixer.music.play(-1)    
                    elif speech_command.lower() == "settings":
                        settings_menu()
                    elif speech_command.lower() == "quit":
                        quit_game()
                elif event.key == pygame.K_ESCAPE:  # Quitting the main menu
                    quit_game()
            elif event.type == pygame.QUIT:
                quit_game()

if __name__ == '__main__':
    main_menu()