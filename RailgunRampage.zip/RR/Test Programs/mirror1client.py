import asyncio
import websockets
import pygame
import io
import zlib
import sys

async def receive_screen(websocket, screen, run_event):
    while run_event.is_set():
        try:
            compressed_data = await websocket.recv()
            img_byte_arr = io.BytesIO(zlib.decompress(compressed_data))
            image = pygame.image.load(img_byte_arr, 'PNG')
            screen.blit(image, (0, 0))
            pygame.display.flip()
        except websockets.exceptions.ConnectionClosed:
            print("Connection closed")
            run_event.clear()
            break

def check_pygame_events(run_event):
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run_event.clear()

async def main():
    uri = "ws://172.30.72.247:8765"
    run_event = asyncio.Event()
    run_event.set()

    pygame.init()
    screen = pygame.display.set_mode((1400, 800))
    pygame.display.set_caption("Screen Mirroring Client")

    async with websockets.connect(uri) as websocket:
        receive_task = asyncio.create_task(receive_screen(websocket, screen, run_event))

        try:
            while run_event.is_set():
                check_pygame_events(run_event)
                await asyncio.sleep(0.01)
        except KeyboardInterrupt:
            print("Client shutdown initiated.")
        finally:
            run_event.clear()
            receive_task.cancel()
            try:
                await receive_task
            except asyncio.CancelledError:
                print("Receive task cancelled.")

if __name__ == "__main__":
    asyncio.run(main())
