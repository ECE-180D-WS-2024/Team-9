import cv2 as cv
import numpy as np
import pygame
import sys

# Initialize Pygame
pygame.init()

SCREEN_WIDTH, SCREEN_HEIGHT = 1400, 800
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Object Tracking")

# Load and scale the crosshair images for blue, red, and now green
crosshair_blue_image = pygame.image.load("crosshair.png").convert_alpha()
crosshair_blue_image = pygame.transform.scale(crosshair_blue_image, (50, 50))

crosshair_red_image = pygame.image.load("crosshair_red.png").convert_alpha()
crosshair_red_image = pygame.transform.scale(crosshair_red_image, (50, 50))

crosshair_green_image = pygame.image.load("crosshair_green.png").convert_alpha()
crosshair_green_image = pygame.transform.scale(crosshair_green_image, (50, 50))

crosshair_yellow_image = pygame.image.load("crosshair_yellow.png").convert_alpha()
crosshair_yellow_image = pygame.transform.scale(crosshair_yellow_image, (50, 50))

def find_objects(frame):
    hsv = cv.cvtColor(frame, cv.COLOR_BGR2HSV)

    # Color ranges
    lower_blue = np.array([90, 100, 100])
    upper_blue = np.array([150, 255, 255])
    lower_red1 = np.array([0, 100, 100])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([160, 100, 100])
    upper_red2 = np.array([180, 255, 255])
    lower_green = np.array([40, 40, 40])
    upper_green = np.array([90, 255, 255])
    lower_yellow = np.array([20, 100, 100])  # Adjust for the right shade of yellow
    upper_yellow = np.array([30, 255, 255])

    # Masks
    blue_mask = cv.inRange(hsv, lower_blue, upper_blue)
    red_mask1 = cv.inRange(hsv, lower_red1, upper_red1)
    red_mask2 = cv.inRange(hsv, lower_red2, upper_red2)
    red_mask = cv.bitwise_or(red_mask1, red_mask2)
    green_mask = cv.inRange(hsv, lower_green, upper_green)
    yellow_mask = cv.inRange(hsv, lower_yellow, upper_yellow)

    # Find centroids and draw bounding boxes for blue, red, and now green
    blue_centroid, frame = process_color(frame, blue_mask, (255, 0, 0))
    red_centroid, frame = process_color(frame, red_mask, (0, 0, 255))
    green_centroid, frame = process_color(frame, green_mask, (0, 255, 0))
    yellow_centroid, frame = process_color(frame, yellow_mask, (0, 255, 255))

    return blue_centroid, red_centroid, green_centroid, yellow_centroid, frame

def process_color(frame, mask, color):
    centroid = None
    contours, _ = cv.findContours(mask, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
    if contours:
        c = max(contours, key=cv.contourArea)
        x, y, w, h = cv.boundingRect(c)
        centroid = (x + w // 2, y + h // 2)
        cv.rectangle(frame, (x, y), (x + w, y + h), color, 2)
    return centroid, frame

cap = cv.VideoCapture(0)

clock = pygame.time.Clock()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            cap.release()
            cv.destroyAllWindows()
            pygame.quit()
            sys.exit()

    _, frame = cap.read()
    if frame is None:
        continue

    blue_centroid, red_centroid, green_centroid, yellow_centroid, frame_with_boxes = find_objects(frame)
    screen.fill((0, 0, 0))  # Clear screen with black background

    # Place crosshairs for detected objects
    for centroid, image in [(blue_centroid, crosshair_blue_image), (red_centroid, crosshair_red_image), (green_centroid, crosshair_green_image), (yellow_centroid, crosshair_yellow_image)]:
        if centroid:
            x, y = centroid
            x = SCREEN_WIDTH - (x * SCREEN_WIDTH // frame.shape[1])
            y = y * SCREEN_HEIGHT // frame.shape[0]
            screen.blit(image, (x - image.get_width() // 2, y - image.get_height() // 2))

    cv.imshow("Camera Feed with Bounding Boxes", frame_with_boxes)
    pygame.display.flip()
    clock.tick(60)

    if cv.waitKey(5) & 0xFF == 27:  # Exit on 'Esc'
        break

cap.release()
cv.destroyAllWindows()
pygame.quit
