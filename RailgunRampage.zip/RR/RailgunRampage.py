# Standard Libraries
import random
import sys
import time
import os
import json
import base64
import io

# GUI Library
import pygame
from pygame.locals import (
    RLEACCEL, K_UP, K_DOWN, K_LEFT, K_RIGHT, K_ESCAPE,
    KEYDOWN, K_f, K_n, QUIT, K_s, K_m, K_2, K_3
)

# Computer Vision Libraries
import cv2
import numpy as np
from PIL import Image

# Asynchronous Operations and Web Sockets Libraries
import asyncio
import websockets
import threading
from queue import Queue

# Speech Recognition Library
import speech_recognition as sr

# Initialize PyGame and Mixer
pygame.init()
pygame.mixer.init()

# Screen and Health Bar Constants
SCREEN_WIDTH = 1400
SCREEN_HEIGHT = 800
HEALTH_BAR_WIDTH = 600
HEALTH_BAR_HEIGHT = 25
HEALTH_BAR_OUTLINE_WIDTH = 5
HEALTH_BAR_OUTLINE_COLOR = (255, 0, 0)
HEALTH_BAR_POSITION = (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 50)

# Player Health and Ammo Management
player_health = 100
max_player_health = 100
max_shots = 5
current_shots = max_shots
winner = ""

# Multiplayer Globals
num_players = 0
score1 = 0
score2 = 0
score3 = 0
score4 = 0
current_shots1 = max_shots
current_shots2 = max_shots
current_shots3 = max_shots
current_shots4 = max_shots

# Sound Effects
shoot_sound = pygame.mixer.Sound('audioRR/shoot.mp3')
shoot_sound.set_volume(0.5)
enemy_dying_sound = pygame.mixer.Sound('audioRR/enemyDying.mp3')
enemy_dying_sound.set_volume(1.0)
reload_sound = pygame.mixer.Sound('audioRR/reload.mp3')
reload_sound.set_volume(1.0)
health_lost_sound = pygame.mixer.Sound('audioRR/healthLoss.mp3')
health_lost_sound.set_volume(2.0)
no_ammo_sound = pygame.mixer.Sound('audioRR/no_ammo.mp3')
no_ammo_sound.set_volume(1.0)
winner_sound = pygame.mixer.Sound('audioRR/winner.mp3')
winner_sound.set_volume(3.0)
game_over_sound = pygame.mixer.Sound('audioRR/gameOver.mp3')
game_over_sound.set_volume(3.0)

# Global Variables
score = 0
command1 = ""
command_queue = Queue()
recognizer = sr.Recognizer()
microphone = sr.Microphone()
player = None
is_paused = False
clock = pygame.time.Clock()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
default_font = pygame.font.Font(None, 36)
cap = cv2.VideoCapture(0)
screen_lock = threading.Lock()

# Queues to Store Centroid Data
blue_centroid_queue = asyncio.Queue()
red_centroid_queue = asyncio.Queue()
green_centroid_queue = asyncio.Queue()
yellow_centroid_queue = asyncio.Queue()

# WebSocket Server Variables
websocket_server = None
websocket_thread = None
websocket_server_running = False
async def handle_websocket_commands(websocket, path):
    global command1
    try:
        client_type = await websocket.recv()
        if client_type == "python_client":
            screen_task = asyncio.create_task(send_screen_updates(websocket))
        elif client_type == "arduino_client":
            screen_task = None
        else:
            print("Unknown client type")
            return
        
        async for message in websocket:
            try:
                data = json.loads(message)
                if 'centroid' in data:
                    await blue_centroid_queue.put(data['centroid'])
                elif 'centroid2' in data:
                    await red_centroid_queue.put(data['centroid2'])
                elif 'centroid3' in data:
                    await green_centroid_queue.put(data['centroid3'])
                elif 'centroid4' in data:
                    await yellow_centroid_queue.put(data['centroid4'])
                else:
                    command1 = message
            except json.JSONDecodeError:
                command1 = message
    except websockets.exceptions.ConnectionClosedError:
        print("WebSocket connection closed with error")
    except Exception as e:
        print(f"Error during WebSocket message handling: {e}")
    finally:
        if screen_task:
            screen_task.cancel()
            await screen_task

async def start_websocket_server():
    global websocket_server, websocket_server_running
    websocket_server = await websockets.serve(handle_websocket_commands, "192.168.137.1", 8765)
    websocket_server_running = True
    await websocket_server.wait_closed()

async def stop_websocket_server():
    global websocket_server, websocket_server_running
    if websocket_server:
        websocket_server.close()
        await websocket_server.wait_closed()
        websocket_server_running = False

def start_websocket_server_thread(loop):
    asyncio.set_event_loop(loop)
    loop.run_until_complete(start_websocket_server())
    loop.run_forever()

# Initialize the WebSocket server in a separate thread
loop = asyncio.new_event_loop()
websocket_thread = threading.Thread(target=start_websocket_server_thread, args=(loop,), name="WebSocketThread")
websocket_thread.start()

#Screen mirroring 
def capture_screen():
    image_str = None
    with screen_lock:
        screen_data = pygame.surfarray.array3d(screen)
    img = Image.fromarray(screen_data)
    img = img.transpose(Image.FLIP_LEFT_RIGHT)
    img = img.transpose(Image.ROTATE_90)
    buffered = io.BytesIO()
    img.save(buffered, format="JPEG", quality=70)
    image_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
    return image_str

async def send_screen_updates(websocket):
    while True:
        screen_capture = capture_screen()
        await websocket.send(screen_capture)
        await asyncio.sleep(1 / 30)  # Approximately 30 FPS

def recognize_speech_from_mic(recognizer, microphone):
    if not isinstance(recognizer, sr.Recognizer):     # Check that the recognizer and microphone arguments are appropriate types
        raise TypeError("`recognizer` must be `Recognizer` instance")   
    if not isinstance(microphone, sr.Microphone):
        raise TypeError("`microphone` must be `Microphone` instance")

    with microphone as source:
        recognizer.adjust_for_ambient_noise(source)  # Adjust for ambient noise
        print("Listening...")  # Signal to the user to start speaking
        try:
            audio = recognizer.listen(source, timeout=5)  # Listen for the first phrase
        except sr.WaitTimeoutError:  # Handling cases where no speech is detected within the timeout
            print("Listening timed out while waiting for speech")
            return ""  # Return an empty string to indicate failure

    try: # Recognize speech using Google Speech Recognition
        transcription = recognizer.recognize_google(audio)
        print(f"Transcription: {transcription}")  # Optional: Print the recognized text
        return transcription  # Return the recognized text
    except sr.RequestError:
        print("Speech Recognition service is unavailable") # API was unreachable or unresponsive
    except sr.UnknownValueError:
        print("Unable to recognize speech") # Speech was unintelligible
    return ""  # Return an empty string if recognition fails

def find_blue_object(frame):
    blurred_frame = cv2.GaussianBlur(frame, (5, 5), 0) # Apply Gaussian Blur to reduce noise and improve color detection
    hsv = cv2.cvtColor(blurred_frame, cv2.COLOR_BGR2HSV) # Convert the blurred frame to HSV color space
    lower_blue = np.array([90, 100, 100]) # Adjust the range for blue color to be more inclusive and robust
    upper_blue = np.array([150, 255, 255])
    mask = cv2.inRange(hsv, lower_blue, upper_blue) # Threshold the HSV image to get only blue colors
    kernel = np.ones((5, 5), np.uint8)  # Apply additional morphological operations like opening to remove small objects or noise
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE) # Find contours in the mask
    filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 500]  # Adjust 500 to your specific needs

    if filtered_contours: # Proceed only if at least one contour was found
        largest_contour = max(filtered_contours, key=cv2.contourArea)  # Find the largest contour among the filtered ones, assuming it's the blue object
        x, y, w, h = cv2.boundingRect(largest_contour)
        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2) # Draw a bounding box around the largest contour
        centroid_blue = (x + w // 2, y + h // 2)
        return centroid_blue

    return None

def find_red_object(frame):
    blurred_frame = cv2.GaussianBlur(frame, (5, 5), 0)  # Apply Gaussian Blur to reduce noise and improve color detection
    hsv = cv2.cvtColor(blurred_frame, cv2.COLOR_BGR2HSV) # Convert the blurred frame to HSV color space
    lower_red1 = np.array([0, 100, 100]) # Low range of red
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([160, 100, 100]) # High range of red
    upper_red2 = np.array([180, 255, 255])
    mask1 = cv2.inRange(hsv, lower_red1, upper_red1) # Threshold the HSV image to get only red colors
    mask2 = cv2.inRange(hsv, lower_red2, upper_red2)
    red_mask = cv2.bitwise_or(mask1, mask2)
    kernel = np.ones((5, 5), np.uint8)  # Apply additional morphological operations like opening to remove small objects or noise
    red_mask = cv2.morphologyEx(red_mask, cv2.MORPH_OPEN, kernel)
    contours, _ = cv2.findContours(red_mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE) # Find contours in the mask
    filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 500]  # Adjust 500 to your specific needs

    if filtered_contours: # Proceed only if at least one contour was found
        largest_contour = max(filtered_contours, key=cv2.contourArea) # Find the largest contour among the filtered ones, assuming it's the red object
        x, y, w, h = cv2.boundingRect(largest_contour)
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 0, 255), 2) # Draw a bounding box around the largest contour
        centroid_red = (x + w // 2, y + h // 2)
        return centroid_red

    return None

def find_green_object(frame):
    blurred_frame = cv2.GaussianBlur(frame, (5, 5), 0)
    hsv = cv2.cvtColor(blurred_frame, cv2.COLOR_BGR2HSV)
    lower_green = np.array([40, 100, 100]) # Adjust the lower range based on your specific green color
    upper_green = np.array([80, 255, 255]) # Adjust the upper range based on your specific green color
    mask = cv2.inRange(hsv, lower_green, upper_green)
    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 500]

    if filtered_contours:
        largest_contour = max(filtered_contours, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(largest_contour)
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        centroid_green = (x + w // 2, y + h // 2)
        return centroid_green

    return None

def find_yellow_object(frame):
    blurred_frame = cv2.GaussianBlur(frame, (5, 5), 0)
    hsv = cv2.cvtColor(blurred_frame, cv2.COLOR_BGR2HSV)
    lower_yellow = np.array([20, 100, 100]) # Adjust the lower range based on your specific yellow color
    upper_yellow = np.array([40, 255, 255]) # Adjust the upper range based on your specific yellow color
    mask = cv2.inRange(hsv, lower_yellow, upper_yellow)
    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 500]

    if filtered_contours:
        largest_contour = max(filtered_contours, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(largest_contour)
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 255), 2)
        centroid_yellow = (x + w // 2, y + h // 2)
        return centroid_yellow
 
    return None

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super(Player, self).__init__()
        self.surf = pygame.image.load("imagesRR/crosshair.png").convert_alpha() # Load the image with transparency preserved
        self.surf = pygame.transform.scale(self.surf, (100, 100)) # Scale the image to the desired size
        self.rect = self.surf.get_rect()

    def update(self):
        ret, frame = cap.read() # Capture the current frame
        if not ret:
            return  # If frame not captured successfully, skip this iteration
        centroid_blue = find_blue_object(frame) # Find the blue object in the frame
        if centroid_blue:
            inverted_x = frame.shape[1] - centroid_blue[0] # Invert the x-coordinate movement
            self.rect.center = (inverted_x * SCREEN_WIDTH // frame.shape[1], centroid_blue[1] * SCREEN_HEIGHT // frame.shape[0])  # Adjust the player's position on screen based on the inverted x-coordinate
        cv2.imshow("Camera Output", frame) # Display the frame in a separate OpenCV window
        cv2.waitKey(1)  # Refresh the display window at short intervals

class Player_2(pygame.sprite.Sprite):
    def __init__(self):
        super(Player_2, self).__init__()
        self.surf = pygame.image.load("imagesRR/crosshair_red.png").convert_alpha() # Load the image with transparency preserved, but use the red crosshair image
        self.surf = pygame.transform.scale(self.surf, (100, 100)) # Scale the image to the desired size
        self.rect = self.surf.get_rect()

    def update(self):
        ret, frame = cap.read() # Capture the current frame
        if not ret:
            return  # If frame not captured successfully, skip this iteration
        centroid_red = find_red_object(frame) # Find the red object in the frame
        if centroid_red:
            inverted_x = frame.shape[1] - centroid_red[0] # Invert the x-coordinate movement
            self.rect.center = (inverted_x * SCREEN_WIDTH // frame.shape[1], centroid_red[1] * SCREEN_HEIGHT // frame.shape[0]) # Adjust the player's position on screen based on the inverted x-coordinate
        cv2.imshow("Camera Output", frame) # Display the frame in a separate OpenCV window
        cv2.waitKey(1)  # Refresh the display window at short intervals

class Player_3(pygame.sprite.Sprite):
    def __init__(self):
        super(Player_3, self).__init__()
        self.surf = pygame.image.load("imagesRR/crosshair_green.png").convert_alpha()  # Load the green crosshair image with transparency
        self.surf = pygame.transform.scale(self.surf, (100, 100))  # Scale the image to the desired size
        self.rect = self.surf.get_rect()

    def update(self):
        ret, frame = cap.read()  # Capture the current frame
        if not ret:
            return  # If frame not captured successfully, skip this iteration
        centroid_green = find_green_object(frame)  # Find the green object in the frame
        if centroid_green:
            inverted_x = frame.shape[1] - centroid_green[0]  # Invert the x-coordinate movement
            self.rect.center = (inverted_x * SCREEN_WIDTH // frame.shape[1], centroid_green[1] * SCREEN_HEIGHT // frame.shape[0])  # Adjust the player's position on screen
        cv2.imshow("Camera Output", frame)  # Display the frame in a separate OpenCV window
        cv2.waitKey(1)  # Refresh the display window at short intervals

class Player_4(pygame.sprite.Sprite):
    def __init__(self):
        super(Player_4, self).__init__()
        self.surf = pygame.image.load("imagesRR/crosshair_yellow.png").convert_alpha()  # Load the yellow crosshair image with transparency
        self.surf = pygame.transform.scale(self.surf, (100, 100))  # Scale the image to the desired size
        self.rect = self.surf.get_rect()

    def update(self):
        ret, frame = cap.read()  # Capture the current frame
        if not ret:
            return  # If frame not captured successfully, skip this iteration
        centroid_yellow = find_yellow_object(frame)  # Find the yellow object in the frame
        if centroid_yellow:
            inverted_x = frame.shape[1] - centroid_yellow[0]  # Invert the x-coordinate movement
            self.rect.center = (inverted_x * SCREEN_WIDTH // frame.shape[1], centroid_yellow[1] * SCREEN_HEIGHT // frame.shape[0])  # Adjust the player's position on screen
        cv2.imshow("Camera Output", frame)  # Display the frame in a separate OpenCV window
        cv2.waitKey(1)  # Refresh the display window at short intervals

class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super(Enemy, self).__init__()
        self.original_surf = pygame.image.load("imagesRR/enemy.png").convert_alpha()  # Load the image, ensuring the use of the alpha channel for transparency
        self.surf = pygame.transform.scale(self.original_surf, (200, 200)) # Scale the image to the desired size (e.g., 50x50 pixels)
        self.rect = self.surf.get_rect(
            center=(
                random.randint(SCREEN_WIDTH + 20, SCREEN_WIDTH + 100),
                random.randint(0, SCREEN_HEIGHT),
            )
        )
        self.speed = random.randint(5, 10)
        self.direction = random.choice([-1, 1])

    def update(self):
        self.rect.move_ip(-self.speed, self.direction)
        if self.rect.right < 0:
            global player_health
            player_health -= 10  # Decrease health by 10%
            if player_health <= 0:
                player_health = 0  # Ensure health doesn't go below 0
            self.kill()
        if self.rect.top <= 0 or self.rect.bottom >= SCREEN_HEIGHT:
            self.direction *= -1  # Change direction when hitting screen edges

class HeavyEnemy(pygame.sprite.Sprite):
    def __init__(self):
        super(HeavyEnemy, self).__init__()
        self.original_surf = pygame.image.load('imagesRR/heavyEnemy.png').convert_alpha()
        self.surf = pygame.transform.scale(self.original_surf, (200, 200)) # Scale the image to the desired size (e.g., 50x50 pixels)
        self.rect = self.surf.get_rect(
            center=(
                random.randint(SCREEN_WIDTH + 20, SCREEN_WIDTH + 100),
                random.randint(0, SCREEN_HEIGHT),
            )
        )
        self.speed = random.randint(5, 10)
        self.health = 2  # Requires two shots to be eliminated
        self.direction = random.choice([-1, 1])

    def update(self):
        self.rect.move_ip(-self.speed, self.direction)
        if self.rect.right < 0:
            global player_health
            player_health -= 15  # Decrease health by 10%
            if player_health <= 0:
                player_health = 0  # Ensure health doesn't go below 0
            self.kill()
        if self.rect.top <= 0 or self.rect.bottom >= SCREEN_HEIGHT:
            self.direction *= -1  # Change direction when hitting screen edges

class Boss(pygame.sprite.Sprite):
    def __init__(self):
        super(Boss, self).__init__()
        self.original_surf = pygame.image.load("imagesRR/boss.png").convert_alpha()
        self.surf = pygame.transform.scale(self.original_surf, (825, 400)) # Adjust the size as needed
        self.rect = self.surf.get_rect(
            center=(
                SCREEN_WIDTH + 100,
                SCREEN_HEIGHT // 2,
            )
        )
        self.health = 50  # Boss health
        self.speed = 1  # Boss speed
        self.direction = random.choice([0,0])  # Boss moves up or down randomly

    def update(self):
        # Move the boss left across the screen and slightly up or down
        self.rect.move_ip(-self.speed, self.direction)
        if self.rect.right < 0:
            self.kill()
        if self.rect.top <= 0 or self.rect.bottom >= SCREEN_HEIGHT:
            self.direction *= -1  # Change direction when hitting screen edges

def draw_text(text, position, font_size=36, color=(255, 0, 0), highlight_color=(50, 50, 50)):
    font = pygame.font.Font(None, font_size) # Set up the font with the specified font size
    text_surface = font.render(text, True, color) # Create the main text surface in red
    text_rect = text_surface.get_rect(center=position)
    highlight_surface = font.render(text, True, highlight_color) # Create a 'highlight' or 'shadow' for the text in dark grey, slightly offset
    highlight_rect = highlight_surface.get_rect(center=(position[0]+2, position[1]+2))  # Adjust the offset values as needed
    screen.blit(highlight_surface, highlight_rect) # Blit the highlight first, then the main text on top
    screen.blit(text_surface, text_rect)

def draw_health_bar(screen, health, position):
    health_bar_x = position[0] - (HEALTH_BAR_WIDTH // 2) # Define the position and size of the health bar
    health_bar_y = position[1]
    health_bar_filled_width = int((health / max_player_health) * HEALTH_BAR_WIDTH)
    outline_rect = pygame.Rect(health_bar_x, health_bar_y, HEALTH_BAR_WIDTH, HEALTH_BAR_HEIGHT) # Draw the health bar outline
    pygame.draw.rect(screen, HEALTH_BAR_OUTLINE_COLOR, outline_rect, HEALTH_BAR_OUTLINE_WIDTH)
    filled_rect = pygame.Rect(health_bar_x, health_bar_y, health_bar_filled_width, HEALTH_BAR_HEIGHT) # Draw the filled part of the health bar
    pygame.draw.rect(screen, (255, 0, 0), filled_rect)

# Define the quit_game function
async def quit_game():
    global websocket_thread, loop
    if websocket_server_running:
        await asyncio.wrap_future(asyncio.run_coroutine_threadsafe(stop_websocket_server(), loop))
    loop.call_soon_threadsafe(loop.stop)
    websocket_thread.join()
    cap.release()  # Release the camera
    cv2.destroyAllWindows()  # Close all OpenCV windows
    pygame.quit()  # Quit pygame
    sys.exit()  # Exit the script

async def game_loop(restart=False):
    global player_health, score, current_shots, max_shots, enemies, all_sprites, running, mic_available, command1

    player = Player()
    multiplier = 100
    boss_spawned = False
    boss_group = pygame.sprite.Group()

    player_health = 100
    score = 0
    current_shots = max_shots

    if restart:
        enemies.empty()
        all_sprites.empty()
        all_sprites.add(player)
        pygame.mixer.music.load('audioRR/in_game_music.mp3')
        pygame.mixer.music.set_volume(0.2)
        pygame.mixer.music.play(-1)

    if not restart:
        pygame.mixer.music.load('audioRR/in_game_music.mp3')
        pygame.mixer.music.set_volume(0.2)
        pygame.mixer.music.play(-1)

    background = pygame.image.load("imagesRR/background.png").convert()
    background = pygame.transform.scale(background, (1900, 1000))

    enemies = pygame.sprite.Group()
    all_sprites = pygame.sprite.Group()
    all_sprites.add(player)

    ADDENEMY = pygame.USEREVENT + 1
    initial_spawn_delay = 10000
    spawn_interval = 2000
    score = 0
    running = True
    game_start_time = pygame.time.get_ticks()
    spawn_delay_passed = False
    mic_available = True
    powerup_available = False
    last_powerup_score = 0

    pygame.time.set_timer(ADDENEMY, initial_spawn_delay)

    async def game_over_screen(score):
        global mic_displayed
        mic_image = pygame.image.load("imagesRR/mic_red.png").convert_alpha()
        mic_image = pygame.transform.scale(mic_image, (100, 100))
        mic_rect = mic_image.get_rect(bottomright=(SCREEN_WIDTH - 10, SCREEN_HEIGHT - 20))

        mic_displayed = False
        mic_activation_time = None

        pygame.mixer.music.pause()
        game_over_sound.play()

        while True:
            current_time = time.time()

            if mic_displayed and mic_activation_time and current_time - mic_activation_time > 5:
                mic_displayed = False
                mic_activation_time = None
                with screen_lock:
                    screen.fill((0, 0, 0), mic_rect)
                    pygame.display.flip()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_p:
                        await game_loop(restart=True)
                        return
                    elif event.key == pygame.K_ESCAPE:
                        await main_menu()
                        return
                    elif event.key == pygame.K_m:
                        mic_displayed = not mic_displayed

                        if mic_displayed:
                            mic_activation_time = current_time
                            with screen_lock:
                                screen.blit(mic_image, mic_rect)
                                pygame.display.flip()

                            speech_command = recognize_speech_from_mic(recognizer, microphone)
                            if speech_command.lower() == "play again":
                                await game_loop(restart=True)
                                return
                            elif speech_command.lower() == "main menu":
                                await main_menu()
                                return
                        else:
                            mic_activation_time = None
                            with screen_lock:
                                screen.fill((0, 0, 0), mic_rect)
                                pygame.display.flip()
                elif event.type == pygame.QUIT:
                    await quit_game()

            with screen_lock:
                screen.fill((0, 0, 0))
                draw_text("GAME OVER", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 8), font_size=120, color=(255, 0, 0))
                draw_text(f"YOUR SCORE: {score}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 4), font_size=120)
                draw_text("PLAY AGAIN", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.3), font_size=80)
                draw_text("MAIN MENU", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2), font_size=80)

                if mic_displayed:
                    screen.blit(mic_image, mic_rect)

                pygame.display.flip()

            await asyncio.sleep(1 / 30)

    async def winner_screen(score):
        global mic_displayed
        mic_image = pygame.image.load("imagesRR/mic_red.png").convert_alpha()
        mic_image = pygame.transform.scale(mic_image, (100, 100))
        mic_rect = mic_image.get_rect(bottomright=(SCREEN_WIDTH - 10, SCREEN_HEIGHT - 20))

        mic_displayed = False
        mic_activation_time = None

        pygame.mixer.music.pause()
        winner_sound.play()

        while True:
            current_time = time.time()

            if mic_displayed and mic_activation_time and current_time - mic_activation_time > 5:
                mic_displayed = False
                mic_activation_time = None
                with screen_lock:
                    screen.fill((0, 0, 0), mic_rect)
                    pygame.display.flip()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_p:
                        await game_loop(restart=True)
                        return
                    elif event.key == pygame.K_ESCAPE:
                        await main_menu()
                        return
                    elif event.key == pygame.K_m:
                        mic_displayed = not mic_displayed

                        if mic_displayed:
                            mic_activation_time = current_time
                            with screen_lock:
                                screen.blit(mic_image, mic_rect)
                                pygame.display.flip()

                            speech_command = recognize_speech_from_mic(recognizer, microphone)
                            if speech_command.lower() == "play again":
                                await game_loop(restart=True)
                                return
                            elif speech_command.lower() == "main menu":
                                await main_menu()
                                return
                        else:
                            mic_activation_time = None
                            with screen_lock:
                                screen.fill((0, 0, 0), mic_rect)
                                pygame.display.flip()
                elif event.type == pygame.QUIT:
                    await quit_game()

            with screen_lock:
                screen.fill((0, 0, 0))
                draw_text("YOU WIN!", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 8), font_size=120, color=(255, 0, 0))
                draw_text(f"TOP SCORE: {score}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 4), font_size=120)
                draw_text("PLAY AGAIN", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.3), font_size=80)
                draw_text("MAIN MENU", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2), font_size=80)

                if mic_displayed:
                    screen.blit(mic_image, mic_rect)

                pygame.display.flip()

            await asyncio.sleep(1 / 30)

    def get_current_level(score):
        if score >= 5000:
            return "BOSS LEVEL"
        elif score >= 3000:
            return "LEVEL 3"
        elif score >= 1000:
            return "LEVEL 2"
        else:
            return "LEVEL 1"

    while running:
        current_time = pygame.time.get_ticks()

        if not spawn_delay_passed and current_time - game_start_time > initial_spawn_delay:
            pygame.time.set_timer(ADDENEMY, spawn_interval)
            spawn_delay_passed = True

        if is_paused:
            await pause_menu()
            continue

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    await pause_menu()
                elif event.key == pygame.K_UP:
                    running = False
                    await game_over_screen(score)
                elif event.key == pygame.K_f:
                    if current_shots > 0:
                        shoot_sound.play()
                        for enemy in pygame.sprite.spritecollide(player, enemies, dokill=False):
                            if isinstance(enemy, HeavyEnemy):
                                enemy.health -= 1
                                if enemy.health <= 0:
                                    enemy.kill()
                                    score += 2 * multiplier
                            else:
                                enemy.kill()
                                score += multiplier
                        for boss in pygame.sprite.spritecollide(player, boss_group, dokill=False):
                            boss.health -= 1
                            if boss.health <= 0:
                                boss.kill()
                                await winner_screen(score)
                                return
                        current_shots -= 1
                        command1 = ""
                    else:
                        no_ammo_sound.play()
                        command1 = ""
                elif event.key == pygame.K_r:
                    reload_sound.play()
                    current_shots = max_shots
                    command1 = ""
            elif event.type == pygame.QUIT:
                running = False
            elif event.type == ADDENEMY and spawn_delay_passed:
                if score < 1000:
                    new_enemy = Enemy()
                elif 1000 <= score < 3000:
                    if random.randint(0, 10) > 5:
                        new_enemy = HeavyEnemy()
                    else:
                        new_enemy = Enemy()
                elif 3000 <= score < 6000:
                    if random.randint(0, 10) > 3:
                        new_enemy = HeavyEnemy()
                    else:
                        new_enemy = Enemy()
                enemies.add(new_enemy)
                all_sprites.add(new_enemy)

        if command1 == "shoot":
            if current_shots > 0:
                shoot_sound.play()
                for enemy in pygame.sprite.spritecollide(player, enemies, dokill=False):
                    if isinstance(enemy, HeavyEnemy):
                        enemy.health -= 1
                        if enemy.health <= 0:
                            enemy.kill()
                            score += 2 * multiplier
                    else:
                        enemy.kill()
                        score += multiplier
                for boss in pygame.sprite.spritecollide(player, boss_group, dokill=False):
                    boss.health -= 1
                    if boss.health <= 0:
                        boss.kill()
                        await winner_screen(score)
                        return
                current_shots -= 1
                command1 = ""
            else:
                no_ammo_sound.play()
                command1 = ""
        elif command1 == "reload":
            reload_sound.play()
            current_shots = max_shots
            command1 = ""

        if score >= last_powerup_score + 1000:
            powerup_available = True
            last_powerup_score = score
        elif command1 == "powerup_doublepts" and powerup_available:
            multiplier = 200
            powerup_available = False
            command1 = ""
        elif command1 == "powerup_nuke" and powerup_available:
            num_enemies_eliminated = len(enemies)
            for enemy in list(enemies):
                all_sprites.remove(enemy)
                enemies.remove(enemy)
            score += 100 * num_enemies_eliminated
            powerup_available = False
            command1 = ""

        player.update()

        for enemy in enemies:
            enemy.update()
            if enemy.rect.right < 0:
                health_lost_sound.play()
                enemy.kill()
                player_health -= 10

        new_spawn_interval = spawn_interval
        if score >= 5000:
            if not boss_spawned:
                boss = Boss()
                boss_group.add(boss)
                all_sprites.add(boss)
                boss_spawned = True
            new_spawn_interval = 800
        elif score >= 3000:
            new_spawn_interval = 800
        elif score >= 1000:
            new_spawn_interval = 1000

        if new_spawn_interval != spawn_interval:
            spawn_interval = new_spawn_interval
            pygame.time.set_timer(ADDENEMY, spawn_interval)

        boss_group.update()

        for boss in boss_group:
            boss.update()
            boss_group.update()
            if boss.rect.right < 0:
                health_lost_sound.play()
                boss.kill()
                player_health -= 100

        if player_health <= 0:
            await game_over_screen(score)
            break

        with screen_lock:
            screen.blit(background, (0, 0))
            draw_health_bar(screen, player_health, HEALTH_BAR_POSITION)
            for entity in all_sprites:
                screen.blit(entity.surf, entity.rect)

            draw_text("WALL HEALTH", (HEALTH_BAR_POSITION[0], HEALTH_BAR_POSITION[1] - 40), font_size=60)
            mag_text = f"BLASTS: {current_shots}/{max_shots}"
            draw_text(mag_text, (SCREEN_WIDTH - 220, SCREEN_HEIGHT - 30), font_size=60)
            draw_text(f"SCORE: {score}", (SCREEN_WIDTH * 0.5, SCREEN_HEIGHT * 0.05), font_size=80)

            current_level = get_current_level(score)
            draw_text(current_level, (SCREEN_WIDTH * 0.5, SCREEN_HEIGHT * 0.12), font_size=80)

            pygame.display.flip()

        await asyncio.sleep(1 / 30)

async def multiplayer(num_players, restart=False):
    global player_health, score1, score2, score3, score4, current_shots1, current_shots2, current_shots3, current_shots4, max_shots, all_sprites, running, mic_available, command1
    multiplier1 = multiplier2 = multiplier3 = multiplier4 = 100

    blue_player = Player()
    red_player = Player_2()
    green_player = Player_3() if num_players >= 3 else None
    yellow_player = Player_4() if num_players == 4 else None
    winner = "none"
    boss_spawned = False
    boss_group = pygame.sprite.Group()

    player_health = 100
    score1 = score2 = score3 = score4 = 0
    current_shots1 = current_shots2 = current_shots3 = current_shots4 = max_shots

    if restart:
        enemies.empty()
        winner = "None"
        all_sprites.empty()
        pygame.mixer.music.load('audioRR/in_game_music.mp3')
        pygame.mixer.music.set_volume(0.2)
        pygame.mixer.music.play(-1)

    if not restart:
        pygame.mixer.music.load('audioRR/in_game_music.mp3')
        pygame.mixer.music.set_volume(0.2)
        pygame.mixer.music.play(-1)

    background = pygame.image.load("imagesRR/background.png").convert()
    background = pygame.transform.scale(background, (1400, 800))

    enemies = pygame.sprite.Group()
    all_sprites = pygame.sprite.Group()
    all_sprites.add(blue_player, red_player)

    if green_player:
        all_sprites.add(green_player)
    if yellow_player:
        all_sprites.add(yellow_player)

    ADDENEMY = pygame.USEREVENT + 1
    initial_spawn_delay = 10000
    spawn_interval = 1750
    score1 = 0
    score2 = 0
    running = True
    game_start_time = pygame.time.get_ticks()
    spawn_delay_passed = False
    mic_available = True
    powerup_available = False
    last_powerup_score = 0

    pygame.time.set_timer(ADDENEMY, initial_spawn_delay)

    async def game_over_screen_multiplayer(score1, score2, winner):
        global num_players, mic_displayed
        mic_image = pygame.image.load("imagesRR/mic_red.png").convert_alpha()
        mic_image = pygame.transform.scale(mic_image, (100, 100))
        mic_rect = mic_image.get_rect(bottomright=(SCREEN_WIDTH - 10, SCREEN_HEIGHT - 20))

        mic_displayed = False
        mic_activation_time = None

        pygame.mixer.music.pause()
        game_over_sound.play()

        while True:
            current_time = time.time()

            if mic_displayed and mic_activation_time and current_time - mic_activation_time > 5:
                mic_displayed = False
                mic_activation_time = None
                with screen_lock:
                    screen.fill((0, 0, 0), mic_rect)
                    pygame.display.flip()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_p:
                        await multiplayer(num_players, restart=True)
                        return
                    elif event.key == pygame.K_ESCAPE:
                        await main_menu()
                        return
                    elif event.key == pygame.K_m:
                        mic_displayed = not mic_displayed

                        if mic_displayed:
                            mic_activation_time = current_time
                            with screen_lock:
                                screen.blit(mic_image, mic_rect)
                                pygame.display.flip()

                            speech_command = recognize_speech_from_mic(recognizer, microphone)
                            if speech_command.lower() == "play again":
                                await multiplayer(num_players, restart=True)
                                return
                            elif speech_command.lower() == "main menu":
                                await main_menu()
                                return
                        else:
                            mic_activation_time = None
                            with screen_lock:
                                screen.fill((0, 0, 0), mic_rect)
                                pygame.display.flip()
                elif event.type == pygame.QUIT:
                    await quit_game()

            with screen_lock:
                screen.fill((0, 0, 0))
                draw_text("GAME OVER", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 8), font_size=120, color=(255, 0, 0))
                draw_text(f"PLAYER 1 SCORE: {score1}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 3.5), font_size=120)
                draw_text(f"PLAYER 2 SCORE: {score2}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.5), font_size=120)
                draw_text(f"Winner: {winner}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 1.9), font_size=120)
                draw_text("PLAY AGAIN", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 1.6), font_size=80)
                draw_text("MAIN MENU", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 1.4), font_size=80)

                if mic_displayed:
                    screen.blit(mic_image, mic_rect)

                pygame.display.flip()

            await asyncio.sleep(1 / 30)

    async def winner_screen_multiplayer(score1, score2, winner):
        global num_players, mic_displayed
        mic_image = pygame.image.load("imagesRR/mic_red.png").convert_alpha()
        mic_image = pygame.transform.scale(mic_image, (100, 100))
        mic_rect = mic_image.get_rect(bottomright=(SCREEN_WIDTH - 10, SCREEN_HEIGHT - 20))

        mic_displayed = False
        mic_activation_time = None

        pygame.mixer.music.pause()
        winner_sound.play()

        while True:
            current_time = time.time()

            if mic_displayed and mic_activation_time and current_time - mic_activation_time > 5:
                mic_displayed = False
                mic_activation_time = None
                with screen_lock:
                    screen.fill((0, 0, 0), mic_rect)
                    pygame.display.flip()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_p:
                        await multiplayer(num_players, restart=True)
                        return
                    elif event.key == pygame.K_ESCAPE:
                        await main_menu()
                        return
                    elif event.key == pygame.K_m:
                        mic_displayed = not mic_displayed

                        if mic_displayed:
                            mic_activation_time = current_time
                            with screen_lock:
                                screen.blit(mic_image, mic_rect)
                                pygame.display.flip()

                            speech_command = recognize_speech_from_mic(recognizer, microphone)
                            if speech_command.lower() == "play again":
                                await multiplayer(num_players, restart=True)
                                return
                            elif speech_command.lower() == "main menu":
                                await main_menu()
                                return
                        else:
                            mic_activation_time = None
                            with screen_lock:
                                screen.fill((0, 0, 0), mic_rect)
                                pygame.display.flip()
                elif event.type == pygame.QUIT:
                    await quit_game()

            with screen_lock:
                screen.fill((0, 0, 0))
                draw_text("YOU WIN!", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 8), font_size=120, color=(0, 255, 0))
                draw_text(f"PLAYER 1 SCORE: {score1}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 3.5), font_size=120)
                draw_text(f"PLAYER 2 SCORE: {score2}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.5), font_size=120)
                draw_text(f"Winner: {winner}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 1.9), font_size=120)
                draw_text("PLAY AGAIN", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 1.6), font_size=80)
                draw_text("MAIN MENU", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 1.4), font_size=80)

                if mic_displayed:
                    screen.blit(mic_image, mic_rect)

                pygame.display.flip()

            await asyncio.sleep(1 / 30)

    def get_current_level(score):
        if score >= 5000:
            return "BOSS LEVEL"
        elif score >= 3000:
            return "LEVEL 3"
        elif score >= 1000:
            return "LEVEL 2"
        else:
            return "LEVEL 1"

    while running:
        current_time = pygame.time.get_ticks()
        combined_score = score1 + score2 + (score3 if green_player else 0) + (score4 if yellow_player else 0)

        if not spawn_delay_passed and current_time - game_start_time > initial_spawn_delay:
            pygame.time.set_timer(ADDENEMY, spawn_interval)
            spawn_delay_passed = True

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    await pause_menu()
                elif event.key == pygame.K_UP:
                    running = False
                    await game_over_screen_multiplayer(score1, score2, winner)
                elif event.key == pygame.K_f:
                    if current_shots1 > 0:
                        shoot_sound.play()
                        for enemy in pygame.sprite.spritecollide(blue_player, enemies, dokill=False):
                            if isinstance(enemy, HeavyEnemy):
                                enemy.health -= 1
                                if enemy.health <= 0:
                                    enemy.kill()
                                    score1 += 2 * multiplier1
                            else:
                                enemy.kill()
                                score1 += multiplier1
                        for boss in pygame.sprite.spritecollide(blue_player, boss_group, dokill=False):
                            boss.health -= 1
                            if boss.health <= 0:
                                boss.kill()
                                await winner_screen_multiplayer(score1, score2, winner)
                                break
                        current_shots1 -= 1
                        command1 = ""
                    else:
                        no_ammo_sound.play()
                        command1 = ""
                elif event.key == pygame.K_r:
                    reload_sound.play()
                    current_shots1 = max_shots
                    command1 = ""
            elif event.type == ADDENEMY and spawn_delay_passed:
                combined_score = score1 + score2 + (score3 if green_player else 0) + (score4 if yellow_player else 0)
                if combined_score < 1000:
                    new_enemy = Enemy()
                elif 1000 <= combined_score < 3000:
                    if random.randint(0, 10) > 4:
                        new_enemy = HeavyEnemy()
                    else:
                        new_enemy = Enemy()
                else:
                    if random.randint(0, 10) > 3:
                        new_enemy = HeavyEnemy()
                    else:
                        new_enemy = Enemy()
                enemies.add(new_enemy)
                all_sprites.add(new_enemy)
            elif event.type == pygame.QUIT:
                running = False

        if command1 == "shoot":
            if current_shots1 > 0:
                shoot_sound.play()
                for enemy in pygame.sprite.spritecollide(blue_player, enemies, dokill=False):
                    if isinstance(enemy, HeavyEnemy):
                        enemy.health -= 1
                        if enemy.health <= 0:
                            enemy.kill()
                            score1 += 2 * multiplier1
                    else:
                        enemy.kill()
                        score1 += multiplier1
                for boss in pygame.sprite.spritecollide(blue_player, boss_group, dokill=False):
                    boss.health -= 1
                    if boss.health <= 0:
                        boss.kill()
                        await winner_screen_multiplayer(score1, score2, winner)
                        break
                current_shots1 -= 1
                command1 = ""
            else:
                no_ammo_sound.play()
                command1 = ""
        elif command1 == "reload":
            reload_sound.play()
            current_shots1 = max_shots
            command1 = ""
        elif command1 == "powerup_doublepts":
            multiplier1 = 200
            command1 = ""
        elif command1 == "powerup_nuke":
            num_enemies_eliminated = len(enemies)
            for enemy in list(enemies):
                all_sprites.remove(enemy)
                enemies.remove(enemy)
            score1 += 100 * num_enemies_eliminated
            command1 = ""

        if command1 == "shoot2":
            if current_shots2 > 0:
                shoot_sound.play()
                for enemy in pygame.sprite.spritecollide(red_player, enemies, dokill=False):
                    if isinstance(enemy, HeavyEnemy):
                        enemy.health -= 1
                        if enemy.health <= 0:
                            enemy.kill()
                            score2 += 2 * multiplier2
                    else:
                        enemy.kill()
                        score2 += multiplier2
                for boss in pygame.sprite.spritecollide(red_player, boss_group, dokill=False):
                    boss.health -= 1
                    if boss.health <= 0:
                        boss.kill()
                        await winner_screen_multiplayer(score1, score2, winner)
                        break
                current_shots2 -= 1
                command1 = ""
            else:
                no_ammo_sound.play()
                command1 = ""
        elif command1 == "reload2":
            reload_sound.play()
            current_shots2 = max_shots
            command1 = ""
        elif command1 == "powerup_doublepts2":
            multiplier2 = 200
            command1 = ""
        elif command1 == "powerup_nuke2":
            num_enemies_eliminated = len(enemies)
            for enemy in list(enemies):
                all_sprites.remove(enemy)
                enemies.remove(enemy)
            score2 += 100 * num_enemies_eliminated
            command1 = ""

        if command1 == "shoot3" and green_player:
            if current_shots3 > 0:
                shoot_sound.play()
                for enemy in pygame.sprite.spritecollide(green_player, enemies, dokill=False):
                    if isinstance(enemy, HeavyEnemy):
                        enemy.health -= 1
                        if enemy.health <= 0:
                            enemy.kill()
                            score3 += 2 * multiplier3
                    else:
                        enemy.kill()
                        score3 += multiplier3
                for boss in pygame.sprite.spritecollide(green_player, boss_group, dokill=False):
                    boss.health -= 1
                    if boss.health <= 0:
                        boss.kill()
                        await winner_screen_multiplayer(score1, score2, winner)
                        break
                current_shots3 -= 1
                command1 = ""
            else:
                no_ammo_sound.play()
                command1 = ""
        elif command1 == "reload3" and green_player:
            reload_sound.play()
            current_shots3 = max_shots
            command1 = ""
        elif command1 == "powerup_doublepts3" and green_player:
            multiplier3 = 200
            command1 = ""
        elif command1 == "powerup_nuke3" and green_player:
            num_enemies_eliminated = len(enemies)
            for enemy in list(enemies):
                all_sprites.remove(enemy)
                enemies.remove(enemy)
            score3 += 100 * num_enemies_eliminated
            command1 = ""

        if command1 == "shoot4" and yellow_player:
            if current_shots4 > 0:
                shoot_sound.play()
                for enemy in pygame.sprite.spritecollide(yellow_player, enemies, dokill=False):
                    if isinstance(enemy, HeavyEnemy):
                        enemy.health -= 1
                        if enemy.health <= 0:
                            enemy.kill()
                            score4 += 2 * multiplier4
                    else:
                        enemy.kill()
                        score4 += multiplier4
                for boss in pygame.sprite.spritecollide(yellow_player, boss_group, dokill=False):
                    boss.health -= 1
                    if boss.health <= 0:
                        boss.kill()
                        await winner_screen_multiplayer(score1, score2, winner)
                        break
                current_shots4 -= 1
                command1 = ""
            else:
                no_ammo_sound.play()
                command1 = ""
        elif command1 == "reload4" and yellow_player:
            reload_sound.play()
            current_shots4 = max_shots
            command1 = ""
        elif command1 == "powerup_doublepts4" and yellow_player:
            multiplier4 = 200
            command1 = ""
        elif command1 == "powerup_nuke4" and yellow_player:
            num_enemies_eliminated = len(enemies)
            for enemy in list(enemies):
                all_sprites.remove(enemy)
                enemies.remove(enemy)
            score4 += 100 * num_enemies_eliminated
            command1 = ""

        blue_player.update()
        red_player.update()
        if green_player:
            green_player.update()
        if yellow_player:
            yellow_player.update()

        winner = "blue"
        highest_score = score1

        if score2 > highest_score:
            winner = "red"
            highest_score = score2

        if green_player and score3 > highest_score:
            winner = "green"
            highest_score = score3

        if yellow_player and score4 > highest_score:
            winner = "yellow"
            highest_score = score4

        for enemy in enemies:
            enemy.update()
            if enemy.rect.right < 0:
                health_lost_sound.play()
                enemy.kill()
                player_health -= 10

        if combined_score >= 5000 and not boss_spawned:
            boss = Boss()
            boss_group.add(boss)
            all_sprites.add(boss)
            boss_spawned = True

        new_spawn_interval = spawn_interval
        if combined_score >= 5000:
            new_spawn_interval = 800
        elif combined_score >= 3000:
            new_spawn_interval = 800
        elif combined_score >= 1000:
            new_spawn_interval = 1000

        if new_spawn_interval != spawn_interval:
            spawn_interval = new_spawn_interval
            pygame.time.set_timer(ADDENEMY, spawn_interval)

        boss_group.update()

        for boss in boss_group:
            if boss.rect.right < 0:
                health_lost_sound.play()
                boss.kill()
                player_health -= 100
                if player_health <= 0:
                    player_health = 0

        if player_health <= 0:
            await game_over_screen_multiplayer(score1, score2, winner)
            break

        with screen_lock:
            screen.blit(background, (0, 0))
            for entity in all_sprites:
                screen.blit(entity.surf, entity.rect)

            draw_health_bar(screen, player_health, HEALTH_BAR_POSITION)
            draw_text("WALL HEALTH", (HEALTH_BAR_POSITION[0], HEALTH_BAR_POSITION[1] - 40), font_size=60)

            draw_text(f"SCORE: {score1}", (70, 20), font_size=36, color=(0, 0, 255))
            draw_text(f"SHOTS: {current_shots1}", (70, 50), font_size=36, color=(0, 0, 255))

            draw_text(f"SCORE: {score2}", (SCREEN_WIDTH - 70, 20), font_size=36, color=(255, 0, 0))
            draw_text(f"SHOTS: {current_shots2}", (SCREEN_WIDTH - 70, 50), font_size=36, color=(255, 0, 0))

            if green_player:
                draw_text(f"SCORE: {score3}", (70, SCREEN_HEIGHT - 60), font_size=36, color=(0, 255, 0))
                draw_text(f"SHOTS: {current_shots3}", (70, SCREEN_HEIGHT - 30), font_size=36, color=(0, 255, 0))

            if yellow_player:
                draw_text(f"SCORE: {score4}", (SCREEN_WIDTH - 70, SCREEN_HEIGHT - 60), font_size=36, color=(255, 255, 0))
                draw_text(f"SHOTS: {current_shots4}", (SCREEN_WIDTH - 70, SCREEN_HEIGHT - 30), font_size=36, color=(255, 255, 0))

            current_level = get_current_level(combined_score)
            draw_text(current_level, (SCREEN_WIDTH * 0.5, SCREEN_HEIGHT * 0.05), font_size=80)

            pygame.display.flip()
        await asyncio.sleep(1 / 30)


# Define the async function to update the player's crosshair
async def player_web(run_event, red_crosshair_rect, green_crosshair_rect, yellow_crosshair_rect):
    red_crosshair_image = pygame.image.load("imagesRR/crosshair_red.png").convert_alpha()
    red_crosshair_image = pygame.transform.scale(red_crosshair_image, (50, 50))

    green_crosshair_image = pygame.image.load("imagesRR/crosshair_green.png").convert_alpha()
    green_crosshair_image = pygame.transform.scale(green_crosshair_image, (50, 50))

    yellow_crosshair_image = pygame.image.load("imagesRR/crosshair_yellow.png").convert_alpha()
    yellow_crosshair_image = pygame.transform.scale(yellow_crosshair_image, (50, 50))

    while run_event.is_set():
        if not red_centroid_queue.empty():
            centroid2 = await red_centroid_queue.get()
            x2, y2 = centroid2
            x2 = x2 * SCREEN_WIDTH // 640  # Adjust these values according to your scaling needs
            y2 = y2 * SCREEN_HEIGHT // 480
            red_crosshair_rect.center = (x2, y2)

        if not green_centroid_queue.empty():
            centroid3 = await green_centroid_queue.get()
            x3, y3 = centroid3
            x3 = x3 * SCREEN_WIDTH // 640  # Adjust these values according to your scaling needs
            y3 = y3 * SCREEN_HEIGHT // 480
            green_crosshair_rect.center = (x3, y3)

        if not yellow_centroid_queue.empty():
            centroid4 = await yellow_centroid_queue.get()
            x4, y4 = centroid4
            x4 = x4 * SCREEN_WIDTH // 640  # Adjust these values according to your scaling needs
            y4 = y4 * SCREEN_HEIGHT // 480
            yellow_crosshair_rect.center = (x4, y4)

        screen.blit(red_crosshair_image, red_crosshair_rect)  # Blit the red crosshair to its new position
        screen.blit(green_crosshair_image, green_crosshair_rect)  # Blit the green crosshair to its new position
        screen.blit(yellow_crosshair_image, yellow_crosshair_rect)  # Blit the yellow crosshair to its new position
        pygame.display.update([red_crosshair_rect, green_crosshair_rect, yellow_crosshair_rect])  # Update only the parts of the screen that contain the crosshairs
        await asyncio.sleep(0.016)  # Frame delay

async def spawn_enemies(run_event, enemies, all_sprites):
    global score1, score2, score3, score4
    spawn_interval = 5.0  # Initial spawn interval for level 1
    
    while run_event.is_set():

        combined_score = score1 + score2 + (score3 if score3 is not None else 0) + (score4 if score4 is not None else 0)

         # Adjust spawn interval based on combined score thresholds
        if combined_score >= 5000:
            spawn_interval = 1.5  # High spawn rate after boss is spawned
        elif combined_score >= 3000:
            spawn_interval = 2.0  # Increase spawn rate for level 3
        elif combined_score >= 1000:
            spawn_interval = 3.0  # Increase spawn rate for level 2
        else:
            spawn_interval = 5.0  # Level 1 spawn rate

        # Spawn enemy
        if combined_score < 1000:
            new_enemy = Enemy()
        elif 1000 <= combined_score < 3000:
            new_enemy = HeavyEnemy() if random.randint(0, 10) > 4 else Enemy()  # 60% chance for HeavyEnemy
        else:
            new_enemy = HeavyEnemy() if random.randint(0, 10) > 3 else Enemy()  # 70% chance for HeavyEnemy

        enemies.add(new_enemy)
        all_sprites.add(new_enemy)

        await asyncio.sleep(2.5)  # Adjust timing as necessary for game balance

async def check_collisions_and_handle_commands(run_event, enemies, all_sprites, blue_crosshair_rect, red_crosshair_rect, green_crosshair_rect, yellow_crosshair_rect):
    global command1, score1, score2, score3, score4, current_shots1, current_shots2, current_shots3, current_shots4
    
    multiplier1 = 100
    multiplier2 = 100
    multiplier3 = 100
    multiplier4 = 100
    powerup_available1 = False
    powerup_available2 = False
    powerup_available3 = False
    powerup_available4 = False

    while run_event.is_set():
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_f:
                    if current_shots1 > 0:
                        shoot_sound.play()
                        for enemy in pygame.sprite.spritecollide(blue_crosshair_rect, enemies, dokill=False):
                            if isinstance(enemy, HeavyEnemy):
                                enemy.health -= 1
                                if enemy.health <= 0:
                                    enemy.kill()
                                    score1 += 2 * multiplier1  # Update the score for killing HeavyEnemy
                            else:
                                enemy.kill()
                                score1 += multiplier1  # Update the score for killing regular Enemy
                        for boss in pygame.sprite.spritecollide(blue_crosshair_rect, boss_group, dokill=False):
                            boss.health -= 1  # Decrease boss health by a fixed amount per shot
                            if boss.health <= 0:
                                boss.kill()
                               # winner_screen(score1)
                                return
                        current_shots1 -= 1
                        command1 = ""  # Reset command1 after processing
                    else:
                        no_ammo_sound.play()
                        command1 = ""  # Reset command1 if there's no ammo
                elif event.key == pygame.K_r:
                    reload_sound.play()
                    current_shots1 = max_shots  # Reset to maximum shots
                    command1 = ""  # Reset command1 after processing
        if command1 == "shoot":
            if current_shots1 > 0:
                shoot_sound.play()
                hit_enemies_blue = [enemy for enemy in enemies if enemy.rect.colliderect(blue_crosshair_rect)]
                for enemy in hit_enemies_blue:
                    enemy.kill()  # Removes the enemy from all sprite groups it belongs to
                    score1 += multiplier1  # Update player 1's score
                current_shots1 -= 1  # Decrement player 1's shots
            else:
                no_ammo_sound.play()
            command1 = ""  # Reset command after processing

        elif command1 == "shoot2":
            if current_shots2 > 0:
                shoot_sound.play()
                hit_enemies_red = [enemy for enemy in enemies if enemy.rect.colliderect(red_crosshair_rect)]
                for enemy in hit_enemies_red:
                    enemy.kill()  # Removes the enemy from all sprite groups it belongs to
                    score2 += multiplier2  # Update player 2's score
                current_shots2 -= 1  # Decrement player 2's shots
            else:
                no_ammo_sound.play()
            command1 = ""  # Reset command after processing

        elif command1 == "shoot3":
            if current_shots3 > 0:
                shoot_sound.play()
                hit_enemies_green = [enemy for enemy in enemies if enemy.rect.colliderect(green_crosshair_rect)]
                for enemy in hit_enemies_green:
                    enemy.kill()  # Removes the enemy from all sprite groups it belongs to
                    score3 += multiplier3  # Update player 3's score
                current_shots3 -= 1  # Decrement player 3's shots
            else:
                no_ammo_sound.play()
            command1 = ""  # Reset command after processing

        elif command1 == "shoot4":
            if current_shots4 > 0:
                shoot_sound.play()
                hit_enemies_yellow = [enemy for enemy in enemies if enemy.rect.colliderect(yellow_crosshair_rect)]
                for enemy in hit_enemies_yellow:
                    enemy.kill()  # Removes the enemy from all sprite groups it belongs to
                    score4 += multiplier4  # Update player 4's score
                current_shots4 -= 1  # Decrement player 4's shots
            else:
                no_ammo_sound.play()
            command1 = ""  # Reset command after processing

        elif command1 == "reload":
            reload_sound.play()
            current_shots1 = max_shots  # Reset player 1's shots
            command1 = ""  # Reset command after processing

        elif command1 == "reload2":
            reload_sound.play()
            current_shots2 = max_shots  # Reset player 2's shots
            command1 = ""  # Reset command after processing

        elif command1 == "reload3":
            reload_sound.play()
            current_shots3 = max_shots  # Reset player 3's shots
            command1 = ""  # Reset command after processing

        elif command1 == "reload4":
            reload_sound.play()
            current_shots4 = max_shots  # Reset player 4's shots
            command1 = ""  # Reset command after processing

        elif command1 == "powerup_doublepts":
            multiplier1 = 200
            command1 = ""  # Reset command after processing

        elif command1 == "powerup_nuke":
            num_enemies_eliminated = len(enemies)  # Count the number of enemies before eliminating them
            for enemy in list(enemies):  # Ensure to iterate over a copy of the group list
                all_sprites.remove(enemy)  # Remove each enemy from the all_sprites group for rendering purposes
                enemies.remove(enemy)  # Also remove from enemies group to ensure it's cleared from logic handling
            score1 += multiplier1 * num_enemies_eliminated  # Award points based on multiplier1 for each enemy eliminated by the nuke
            command1 = ""  # Reset command after processing to avoid repeatedly triggering the nuke

        elif command1 == "powerup_doublepts2":
            multiplier2 = 200
            command1 = ""  # Reset command after processing

        elif command1 == "powerup_nuke2":
            num_enemies_eliminated = len(enemies)  # Count the number of enemies before eliminating them
            for enemy in list(enemies):  # Ensure to iterate over a copy of the group list
                all_sprites.remove(enemy)  # Remove each enemy from the all_sprites group for rendering purposes
                enemies.remove(enemy)  # Also remove from enemies group to ensure it's cleared from logic handling
            score2 += multiplier2 * num_enemies_eliminated  # Award points based on multiplier2 for each enemy eliminated by the nuke
            command1 = ""  # Reset command after processing to avoid repeatedly triggering the nuke

        elif command1 == "powerup_doublepts3":
            multiplier3 = 200
            command1 = ""  # Reset command after processing

        elif command1 == "powerup_nuke3":
            num_enemies_eliminated = len(enemies)  # Count the number of enemies before eliminating them
            for enemy in list(enemies):  # Ensure to iterate over a copy of the group list
                all_sprites.remove(enemy)  # Remove each enemy from the all_sprites group for rendering purposes
                enemies.remove(enemy)  # Also remove from enemies group to ensure it's cleared from logic handling
            score3 += multiplier3 * num_enemies_eliminated  # Award points based on multiplier3 for each enemy eliminated by the nuke
            command1 = ""  # Reset command after processing to avoid repeatedly triggering the nuke

        elif command1 == "powerup_doublepts4":
            multiplier4 = 200
            command1 = ""  # Reset command after processing

        elif command1 == "powerup_nuke4":
            num_enemies_eliminated = len(enemies)  # Count the number of enemies before eliminating them
            for enemy in list(enemies):  # Ensure to iterate over a copy of the group list
                all_sprites.remove(enemy)  # Remove each enemy from the all_sprites group for rendering purposes
                enemies.remove(enemy)  # Also remove from enemies group to ensure it's cleared from logic handling
            score4 += multiplier4 * num_enemies_eliminated  # Award points based on multiplier4 for each enemy eliminated by the nuke
            command1 = ""  # Reset command after processing to avoid repeatedly triggering the nuke

        await asyncio.sleep(0.1)  # Check periodically, adjust delay as needed

async def multiple_cameras():
    global screen, is_paused, score1, score2, score3, score4, current_shots1, current_shots2, current_shots3, current_shots4, max_shots, player_health, max_player_health
    pygame.init()
    SCREEN_WIDTH, SCREEN_HEIGHT = 1400, 800
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

    def reset_game_state():
        global score1, score2, score3, score4, current_shots1, current_shots2, current_shots3, current_shots4, player_health
        score1, score2, score3, score4 = 0, 0, 0, 0
        current_shots1, current_shots2, current_shots3, current_shots4 = max_shots, max_shots, max_shots, max_shots
        player_health = max_player_health  # Reset player health
        enemies.empty()
        all_sprites.empty()

    async def game_over_screen_multiple_cameras():
        global mic_displayed, score1, score2, score3, score4
        mic_image = pygame.image.load("imagesRR/mic_red.png").convert_alpha()
        mic_image = pygame.transform.scale(mic_image, (100, 100))  # Scale to 100x100 pixels
        mic_rect = mic_image.get_rect(bottomright=(SCREEN_WIDTH - 10, SCREEN_HEIGHT - 20))  # Adjusted position to be slightly higher

        mic_displayed = False
        mic_activation_time = None

        pygame.mixer.music.pause()  # Pause the in-game music
        game_over_sound.play()

        with screen_lock:
            screen.fill((0, 0, 0))  # Clear the screen
            draw_text("GAME OVER", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 7), font_size=200, color=(255, 0, 0))

            # Display scores for each player
            draw_text(f"PLAYER 1 SCORE: {score1}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 3), font_size=100, color=(0, 0, 255))
            draw_text(f"PLAYER 2 SCORE: {score2}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.4), font_size=100, color=(255, 0, 0))
            draw_text(f"PLAYER 3 SCORE: {score3}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2), font_size=100, color=(0, 255, 0))
            draw_text(f"PLAYER 4 SCORE: {score4}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 1.7), font_size=100, color=(255, 255, 0))

            draw_text("PRESS 'P' TO PLAY AGAIN", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 1.35), font_size=80)
            draw_text("PRESS 'ESC' TO MAIN MENU", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 1.25), font_size=80)

            # Blit the microphone image if the flag is set
            if mic_displayed:
                screen.blit(mic_image, mic_rect)

            pygame.display.flip()

        while True:
            current_time = time.time()

            if mic_displayed and mic_activation_time and current_time - mic_activation_time > 5:
                mic_displayed = False
                mic_activation_time = None
                with screen_lock:
                    screen.fill((0, 0, 0), mic_rect)
                    pygame.display.flip()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_p:
                        run_event.set()  # Set the run_event
                        reset_game_state()
                        await multiple_cameras()
                        return
                    elif event.key == pygame.K_ESCAPE:
                        reset_game_state()
                        await main_menu()
                        return
                    elif event.key == pygame.K_m:
                        mic_displayed = not mic_displayed
                        if mic_displayed:
                            mic_activation_time = current_time
                            with screen_lock:
                                screen.blit(mic_image, mic_rect)
                                pygame.display.flip()

                            speech_command = recognize_speech_from_mic(recognizer, microphone)
                            if speech_command.lower() == "play again":
                                run_event.set()  # Set the run_event
                                reset_game_state()
                                await multiple_cameras()
                                return
                            elif speech_command.lower() == "main menu":
                                reset_game_state()
                                await main_menu()
                                return

    background = pygame.image.load("imagesRR/background.png").convert()
    background = pygame.transform.scale(background, (SCREEN_WIDTH, SCREEN_HEIGHT))
    run_event = asyncio.Event()
    run_event.set()

    blue_crosshair_rect = pygame.Rect(0, 0, 50, 50)
    red_crosshair_rect = pygame.Rect(0, 0, 50, 50)
    green_crosshair_rect = pygame.Rect(0, 0, 50, 50)
    yellow_crosshair_rect = pygame.Rect(0, 0, 50, 50)

    enemies = pygame.sprite.Group()
    all_sprites = pygame.sprite.Group()

    # Uncommented the blue_player spawning
    blue_player = Player()
    all_sprites.add(blue_player)

    player_web_task = asyncio.create_task(player_web(run_event, red_crosshair_rect, green_crosshair_rect, yellow_crosshair_rect))
    spawn_task = asyncio.create_task(spawn_enemies(run_event, enemies, all_sprites))
    collision_task = asyncio.create_task(check_collisions_and_handle_commands(run_event, enemies, all_sprites, blue_crosshair_rect, red_crosshair_rect, green_crosshair_rect, yellow_crosshair_rect))  # Passed blue_crosshair_rect
    
    running = True
    while running:
        combined_score = score1 + score2 + (score3 if score3 is not None else 0) + (score4 if score4 is not None else 0)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    is_paused = True
                    await pause_menu()
                    is_paused = False
                elif event.key == pygame.K_r:
                    run_event.clear()
                    await asyncio.gather(player_web_task, spawn_task, collision_task, return_exceptions=True)
                    reset_game_state()
                    run_event.set()
                    player_web_task = asyncio.create_task(player_web(run_event, red_crosshair_rect, green_crosshair_rect, yellow_crosshair_rect))
                    spawn_task = asyncio.create_task(spawn_enemies(run_event, enemies, all_sprites))
                    collision_task = asyncio.create_task(check_collisions_and_handle_commands(run_event, enemies, all_sprites, blue_crosshair_rect, red_crosshair_rect, green_crosshair_rect, yellow_crosshair_rect))  # Passed blue_crosshair_rect
                elif event.key == pygame.K_UP:
                    running = False
                    run_event.clear()
                    await asyncio.gather(player_web_task, spawn_task, collision_task, return_exceptions=True)
                    await game_over_screen_multiple_cameras()

        # Check if player_health is less than or equal to 0
        if player_health <= 0:
            running = False
            run_event.clear()
            await asyncio.gather(player_web_task, spawn_task, collision_task, return_exceptions=True)
            await game_over_screen_multiple_cameras()
            continue

        with screen_lock:
            screen.blit(background, (0, 0))

            for entity in all_sprites:
                entity.update()
                screen.blit(entity.surf, entity.rect)

            draw_health_bar(screen, player_health, (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 50))
            draw_text("WALL HEALTH", (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 90), font_size=60)

            draw_text(f"SCORE: {score1}", (70, 20), font_size=36, color=(0, 0, 255))
            draw_text(f"SHOTS: {current_shots1}", (70, 50), font_size=36, color=(0, 0, 255))

            draw_text(f"SCORE: {score2}", (SCREEN_WIDTH - 70, 20), font_size=36, color=(255, 0, 0))
            draw_text(f"SHOTS: {current_shots2}", (SCREEN_WIDTH - 70, 50), font_size=36, color=(255, 0, 0))

            draw_text(f"SCORE: {score3}", (70, SCREEN_HEIGHT - 60), font_size=36, color=(0, 255, 0))
            draw_text(f"SHOTS: {current_shots3}", (70, SCREEN_HEIGHT - 30), font_size=36, color=(0, 255, 0))

            draw_text(f"SCORE: {score4}", (SCREEN_WIDTH - 70, SCREEN_HEIGHT - 60), font_size=36, color=(255, 255, 0))
            draw_text(f"SHOTS: {current_shots4}", (SCREEN_WIDTH - 70, SCREEN_HEIGHT - 30), font_size=36, color=(255, 255, 0))

            pygame.display.flip()
        await asyncio.sleep(0.016)

    run_event.clear()
    player_web_task.cancel()
    spawn_task.cancel()
    collision_task.cancel()
    await asyncio.gather(player_web_task, spawn_task, collision_task, return_exceptions=True)

    await stop_websocket_server()
    await quit_game()

async def pause_menu():
    global mic_displayed
    mic_image = pygame.image.load("imagesRR/mic_red.png").convert_alpha()
    mic_image = pygame.transform.scale(mic_image, (100, 100))
    mic_rect = mic_image.get_rect(bottomright=(SCREEN_WIDTH - 10, SCREEN_HEIGHT - 20))

    mic_displayed = False
    mic_activation_time = None

    pygame.mixer.music.pause()
    paused = True

    while paused:
        current_time = time.time()

        with screen_lock:
            if mic_displayed and mic_activation_time and current_time - mic_activation_time > 5:
                mic_displayed = False
                mic_activation_time = None
                screen.fill((0, 0, 0), mic_rect)
                pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    paused = False
                    await main_menu()
                elif event.key == pygame.K_p:
                    pygame.mixer.music.unpause()
                    paused = False
                elif event.key == pygame.K_m:
                    mic_displayed = not mic_displayed

                    if mic_displayed:
                        mic_activation_time = current_time
                        with screen_lock:
                            screen.blit(mic_image, mic_rect)
                            pygame.display.flip()

                        speech_command = recognize_speech_from_mic(recognizer, microphone)
                        if speech_command.lower() == "main menu":
                            paused = False
                            await main_menu()
                        elif speech_command.lower() == "resume":
                            pygame.mixer.music.unpause()
                            paused = False
                    else:
                        mic_activation_time = None
                        with screen_lock:
                            screen.fill((0, 0, 0), mic_rect)
                            pygame.display.flip()
            elif event.type == pygame.QUIT:
                await quit_game()

        with screen_lock:
            screen.fill((0, 0, 0))
            draw_text("PAUSED", (SCREEN_WIDTH/2, SCREEN_HEIGHT/8), font_size=120)
            draw_text("MAIN MENU", (SCREEN_WIDTH/2, SCREEN_HEIGHT/2.5), font_size=80)
            draw_text("RESUME", (SCREEN_WIDTH/2, SCREEN_HEIGHT/2), font_size=80)

            if mic_displayed:
                screen.blit(mic_image, mic_rect)

            pygame.display.flip()
        clock.tick(30)

async def settings_menu():
    global mic_displayed
    mic_image = pygame.image.load("imagesRR/mic_red.png").convert_alpha()
    mic_image = pygame.transform.scale(mic_image, (100, 100))
    mic_rect = mic_image.get_rect(bottomright=(SCREEN_WIDTH - 10, SCREEN_HEIGHT - 20))

    mic_displayed = False
    mic_activation_time = None

    in_settings = True
    while in_settings:
        current_time = time.time()

        with screen_lock:
            if mic_displayed and mic_activation_time and current_time - mic_activation_time > 5:
                mic_displayed = False
                mic_activation_time = None
                screen.fill((0, 0, 0), mic_rect)
                pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    in_settings = False
                elif event.key == pygame.K_m:
                    mic_displayed = not mic_displayed
                    if mic_displayed:
                        mic_activation_time = current_time
                        with screen_lock:
                            screen.blit(mic_image, mic_rect)
                            pygame.display.flip()

                        speech_command = recognize_speech_from_mic(recognizer, microphone)
                        if speech_command.lower() == "main menu":
                            in_settings = False
                    else:
                        mic_activation_time = None
                        with screen_lock:
                            screen.fill((0, 0, 0), mic_rect)
                            pygame.display.flip()
            elif event.type == pygame.QUIT:
                await quit_game()

        with screen_lock:
            screen.fill((0, 0, 0))
            draw_text("SETTINGS", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 8), font_size=120)
            draw_text("MAIN MENU", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.5), font_size=80)

            if mic_displayed:
                screen.blit(mic_image, mic_rect)

            pygame.display.flip()
        await asyncio.sleep(1 / 30)  # Maintain a steady framerate

async def select_number_of_players_menu():
    global num_players, mic_available
    menu_running = True
    mic_available = True

    while menu_running:
        screen.fill((0, 0, 0))

        # Title
        draw_text('Select Number of Players', (screen.get_width() / 2, screen.get_height() / 5), font_size=100, color=(255, 0, 0), highlight_color=(50, 50, 50))

        # Options
        options_start_y = screen.get_height() / 3
        row_height = 50
        draw_text('2 Players (Press 2)', (screen.get_width() / 2, options_start_y + row_height * 1), font_size=80, color=(255, 0, 0), highlight_color=(50, 50, 50))
        draw_text('3 Players (Press 3)', (screen.get_width() / 2, options_start_y + row_height * 2), font_size=80, color=(255, 0, 0), highlight_color=(50, 50, 50))
        draw_text('4 Players (Press 4)', (screen.get_width() / 2, options_start_y + row_height * 3), font_size=80, color=(255, 0, 0), highlight_color=(50, 50, 50))
        draw_text('Main Menu (Press ESC)', (screen.get_width() / 2, options_start_y + row_height * 4), font_size=80, color=(255, 0, 0), highlight_color=(50, 50, 50))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                await quit_game()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_2:
                    num_players = 2
                    menu_running = False
                elif event.key == pygame.K_3:
                    num_players = 3
                    menu_running = False
                elif event.key == pygame.K_4:
                    num_players = 4
                    menu_running = False
                elif event.key == pygame.K_ESCAPE:
                    await main_menu()
                    menu_running = False
                elif event.key == pygame.K_m and mic_available:
                    mic_available = False
                    speech_command = recognize_speech_from_mic(recognizer, microphone)
                    if speech_command.lower() == "two":
                        num_players = 2
                        menu_running = False
                    elif speech_command.lower() == "three":
                        num_players = 3
                        menu_running = False
                    elif speech_command.lower() == "four":
                        num_players = 4
                        menu_running = False
                    elif speech_command.lower() == "main menu":
                        await main_menu()
                        menu_running = False
                    mic_available = True

        await asyncio.sleep(1 / 30)

    return num_players

async def main_menu():
    global mic_displayed, is_paused
    main_menu_background = pygame.image.load("imagesRR/main_menu_background.png").convert()
    main_menu_background = pygame.transform.scale(main_menu_background, (SCREEN_WIDTH, SCREEN_HEIGHT))
    mic_image = pygame.image.load("imagesRR/mic_black.png").convert_alpha()
    mic_image = pygame.transform.scale(mic_image, (100, 100))
    mic_rect = mic_image.get_rect(bottomright=(SCREEN_WIDTH - 10, SCREEN_HEIGHT - 20))
    pygame.mixer.music.load('audioRR/main_menu_music.mp3')
    pygame.mixer.music.play(-1)
    mic_displayed = False
    mic_activation_time = None
    menu_running = True
    first_run = True

    while menu_running:
        current_time = time.time()
        with screen_lock:
            if mic_displayed and mic_activation_time and current_time - mic_activation_time > 5:
                mic_displayed = False
                mic_activation_time = None
                screen.blit(main_menu_background, mic_rect, mic_rect)
                pygame.display.flip()

            screen.blit(main_menu_background, (0, 0))
            draw_text("RAILGUN RAMPAGE", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 10), font_size=140)
            draw_text("PLAY (P)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.7 + 30), font_size=80)
            draw_text("LOCAL (2)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.7 + 90), font_size=80)
            draw_text("ONLINE (3)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.7 + 150), font_size=80)
            draw_text("SETTINGS (S)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.7 + 210), font_size=80)
            draw_text("QUIT (ESC)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.7 + 270), font_size=80)

            if mic_displayed:
                screen.blit(mic_image, mic_rect)

            pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    pygame.mixer.music.stop()
                    is_paused = False  # Ensure the game is not paused
                    await game_loop()
                    pygame.mixer.music.play(-1)
                elif event.key == pygame.K_3:
                    pygame.mixer.music.stop()
                    is_paused = False  # Ensure the game is not paused
                    if first_run:
                        await multiple_cameras()
                        first_run = False
                    else:
                        asyncio.create_task(multiple_cameras())
                    pygame.mixer.music.play(-1)
                elif event.key == pygame.K_2:
                    pygame.mixer.music.stop()
                    is_paused = False  # Ensure the game is not paused
                    num_players = await select_number_of_players_menu()  # Await the coroutine here
                    await multiplayer(num_players)
                    pygame.mixer.music.play(-1)
                elif event.key == pygame.K_s:
                    await settings_menu()
                elif event.key == pygame.K_m:
                    mic_displayed = not mic_displayed
                    if mic_displayed:
                        mic_activation_time = current_time
                        with screen_lock:
                            screen.blit(mic_image, mic_rect)
                            pygame.display.flip()
                        speech_command = recognize_speech_from_mic(recognizer, microphone)
                        if speech_command.lower() == "play":
                            pygame.mixer.music.stop()
                            is_paused = False  # Ensure the game is not paused
                            await game_loop()
                            pygame.mixer.music.play(-1)
                        elif speech_command.lower() == "local":
                            pygame.mixer.music.stop()
                            is_paused = False  # Ensure the game is not paused
                            num_players = await select_number_of_players_menu()  # Await the coroutine here
                            await multiplayer(num_players)
                            pygame.mixer.music.play(-1)
                        elif speech_command.lower() == "online":
                            pygame.mixer.music.stop()
                            is_paused = False  # Ensure the game is not paused
                            if first_run:
                                await multiple_cameras()
                                first_run = False
                            else:
                                asyncio.create_task(multiple_cameras())
                                pygame.mixer.music.play(-1)
                        elif speech_command.lower() == "settings":
                            await settings_menu()
                        elif speech_command.lower() == "quit":
                            await quit_game()
                    else:
                        mic_activation_time = None
                        with screen_lock:
                            screen.blit(main_menu_background, mic_rect, mic_rect)
                            pygame.display.flip()
                elif event.key == pygame.K_ESCAPE:
                    await quit_game()
            elif event.type == pygame.QUIT:
                await quit_game()

if __name__ == '__main__':
    asyncio.run(main_menu())
