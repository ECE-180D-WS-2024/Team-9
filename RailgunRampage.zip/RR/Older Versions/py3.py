import random
import sys
import time
import os

# For the GUI
import pygame

# For localization
import cv2
import numpy as np

# For web sockets
import asyncio
import websockets
import threading
import queue
from queue import Queue

# For the speech recognition
import speech_recognition as sr

# Define the command queue globally
command_queue = Queue()

global player
switch_to_settings = False

# Initialize PyGame
pygame.init()
pygame.mixer.init()  # Initialize the mixer module

from pygame.locals import (
    RLEACCEL,
    K_UP,
    K_DOWN,
    K_LEFT,
    K_RIGHT,
    K_ESCAPE,
    KEYDOWN,
    K_f,
    K_n,
    QUIT,
)

# Define constants for the screen width and height
SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 800

# Define constants for the health bar size
HEALTH_BAR_WIDTH = 300  # Total width of the health bar (outline)
HEALTH_BAR_HEIGHT = 15
HEALTH_BAR_OUTLINE_WIDTH = 5  # The width of the outline around the health bar
HEALTH_BAR_OUTLINE_COLOR = (255, 0, 0) 
HEALTH_BAR_POSITION = (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 50)

# Initial health (for example purposes, you'll use your own game's logic)
player_health = 100  # Assuming the player starts with 100 health
max_player_health = 100  # The maximum health

# Load the shooting sound effect
shoot_sound = pygame.mixer.Sound('shoot.mp3')
shoot_sound.set_volume(0.5)  # Set a lower volume for the shooting sound, adjust as needed

# Load the enemy dying sound effect
enemy_dying_sound = pygame.mixer.Sound('enemyDying.mp3')
enemy_dying_sound.set_volume(1.0)  # Set a higher volume for the enemy dying sound, adjust as needed

# Load the reload sound effect
reload_sound = pygame.mixer.Sound('reload.mp3')
reload_sound.set_volume(1.0)

# Load the lost health sound effect
health_lost_sound = pygame.mixer.Sound('healthLoss.mp3')
health_lost_sound.set_volume(2.0)

# Load the no ammo sound effect
no_ammo_sound = pygame.mixer.Sound('no_ammo.mp3')
no_ammo_sound.set_volume(1.0)

# Setup the clock for a decent framerate
clock = pygame.time.Clock()

# Create the screen object
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

# Set up fonts
default_font = pygame.font.Font(None, 36)

# Initialize the camera
cap = cv2.VideoCapture(0)

max_shots = 5
is_paused = False
current_shots = max_shots

# Web Socket function
async def handle_shoot_reload(websocket, path):
    global current_shots, score, enemies, player
    async for message in websocket:
        command_queue.put(message)  # Put the received command into the queue
        if message == "shoot":
            if current_shots > 0:
                shoot_sound.play()
                current_shots -= 1
            else:
                no_ammo_sound.play()
        elif message == "reload":
            reload_sound.play()
            current_shots = max_shots

def start_websocket_server():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    start_server = websockets.serve(handle_shoot_reload, "172.20.10.14", 8765)
    loop.run_until_complete(start_server)
    loop.run_forever()

# Run the WebSocket server in a separate thread
websocket_thread = threading.Thread(target=start_websocket_server, name="WebSocketThread")
websocket_thread.start()

# Localization function
def find_blue_object(frame):
    # Apply Gaussian Blur to reduce noise and improve color detection
    blurred_frame = cv2.GaussianBlur(frame, (5, 5), 0)

    # Convert the blurred frame to HSV color space
    hsv = cv2.cvtColor(blurred_frame, cv2.COLOR_BGR2HSV)

    # Adjust the range for blue color to be more inclusive and robust
    lower_blue = np.array([90, 100, 100])
    upper_blue = np.array([150, 255, 255])

    # Threshold the HSV image to get only blue colors
    mask = cv2.inRange(hsv, lower_blue, upper_blue)

    # Optional: Apply additional morphological operations like opening to remove small objects or noise
    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

    # Find contours in the mask
    contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # Filter contours by area (if needed)
    filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 500]  # Adjust 500 to your specific needs

    # Proceed only if at least one contour was found
    if filtered_contours:
        # Find the largest contour among the filtered ones, assuming it's the blue object
        largest_contour = max(filtered_contours, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(largest_contour)

        # Draw a bounding box around the largest contour
        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)

        centroid = (x + w // 2, y + h // 2)
        return centroid
    return None

def draw_text(text, position, font_size=36, color=(255, 0, 0), highlight_color=(50, 50, 50)):
    # Set up the font with the specified font size
    font = pygame.font.Font(None, font_size)

    # Create the main text surface in red
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect(center=position)

    # Create a 'highlight' or 'shadow' for the text in dark grey, slightly offset
    highlight_surface = font.render(text, True, highlight_color)
    highlight_rect = highlight_surface.get_rect(center=(position[0]+2, position[1]+2))  # Adjust the offset values as needed

    # Blit the highlight first, then the main text on top
    screen.blit(highlight_surface, highlight_rect)
    screen.blit(text_surface, text_rect)

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super(Player, self).__init__()
        # Load the image with transparency preserved
        self.surf = pygame.image.load("crosshair.png").convert_alpha()
        # Scale the image to the desired size
        self.surf = pygame.transform.scale(self.surf, (100, 100)) 
        self.rect = self.surf.get_rect()

    def update(self):
        # Capture the current frame
        ret, frame = cap.read()

        if not ret:
            return  # If frame not captured successfully, skip this iteration

        # Find the blue object in the frame
        centroid = find_blue_object(frame)

        if centroid:
            # Invert the x-coordinate movement
            inverted_x = frame.shape[1] - centroid[0]
            # Adjust the player's position on screen based on the inverted x-coordinate
            self.rect.center = (inverted_x * SCREEN_WIDTH // frame.shape[1], centroid[1] * SCREEN_HEIGHT // frame.shape[0])
        
        # Display the frame in a separate OpenCV window
        cv2.imshow("Camera Output", frame)
        cv2.waitKey(1)  # Refresh the display window at short intervals

class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super(Enemy, self).__init__()
        # Load the image, ensuring the use of the alpha channel for transparency
        self.original_surf = pygame.image.load("enemy.png").convert_alpha()
        # Scale the image to the desired size (e.g., 50x50 pixels)
        self.surf = pygame.transform.scale(self.original_surf, (200, 200))
        self.rect = self.surf.get_rect(
            center=(
                random.randint(SCREEN_WIDTH + 20, SCREEN_WIDTH + 100),
                random.randint(0, SCREEN_HEIGHT),
            )
        )
        self.speed = random.randint(5, 10)

    def update(self):
        self.rect.move_ip(-self.speed, 0)
        if self.rect.right < 0:
            global player_health
            player_health -= 10  # Decrease health by 10%
            if player_health <= 0:
                player_health = 0  # Ensure health doesn't go below 0
            self.kill()

def pause_menu():
    global is_paused

    pygame.mixer.music.pause()  # Pause the in-game music
    paused = True
    
    paused = True
    while paused:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:  # Return to main menu
                    paused = False
                    main_menu()  # This will handle playing the main menu music
                elif event.key == pygame.K_p:  # Resume the game
                    pygame.mixer.music.unpause()  # Unpause the in-game music
                    paused = False
            elif event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        screen.fill((0, 0, 0))
        draw_text("PAUSED", (SCREEN_WIDTH/2, SCREEN_HEIGHT/8), font_size=120)
        draw_text("MAIN MENU (ESC)", (SCREEN_WIDTH/2, SCREEN_HEIGHT/2.5), font_size=80)
        draw_text("RESUME (P)", (SCREEN_WIDTH/2, SCREEN_HEIGHT/2), font_size=80)

        pygame.display.flip()
        clock.tick(30)

def settings_menu():

    in_settings = True
    while in_settings:

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:  # Return to main menu
                    in_settings = False
            elif event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        screen.fill((0, 0, 0))
        draw_text("SETTINGS", (SCREEN_WIDTH/2, SCREEN_HEIGHT/8), font_size=120)
        draw_text("BACK", (SCREEN_WIDTH/2, SCREEN_HEIGHT/2.5), font_size=80)

        pygame.display.flip()
        clock.tick(30)

def game_loop(restart=False):
    global player_health, score, current_shots, max_shots, enemies, all_sprites, running

    if restart:
        # Reset necessary variables for a new game
        player_health = 100  # Reset player's health
        score = 0  # Reset score
        current_shots = max_shots  # Reset ammunition
        enemies.empty()  # Remove all enemy sprites
        all_sprites.empty()  # Remove all sprites
        all_sprites.add(player)  # Add the player sprite back
        pygame.mixer.music.load('in_game_music.mp3')  # Reload in-game music
        pygame.mixer.music.set_volume(0.2)
        pygame.mixer.music.play(-1)

    if not restart:
        # Play in-game music only if not restarting the game
        pygame.mixer.music.load('in_game_music.mp3')
        pygame.mixer.music.set_volume(0.2)  # music volume
        pygame.mixer.music.play(-1)  # Play the music indefinitely

    background = pygame.image.load("background.png").convert()
    background = pygame.transform.scale(background, (1900, 1000))

    player = Player()

    enemies = pygame.sprite.Group()
    all_sprites = pygame.sprite.Group()
    all_sprites.add(player)

    ADDENEMY = pygame.USEREVENT + 1
    spawn_interval = 2500  # Adjust this value as needed to decrease spawn frequency
    score = 0
    running = True
    game_start_time = pygame.time.get_ticks()
    spawn_delay_passed = False

    while running:
        current_time = pygame.time.get_ticks()
        if not spawn_delay_passed and current_time - game_start_time > 10000: # Ten sec delay when starting the game
            pygame.time.set_timer(ADDENEMY, spawn_interval)
            spawn_delay_passed = True

        if is_paused:
            pause_menu()  # Display the pause menu
            #is_paused = False
            continue  # Skip the rest of the game loop

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pause_menu()
                elif event.key == pygame.K_UP: # UNCOMMENT TO TEST GAME OVER SCREEN
                    running = False
                    game_over_screen(score)
            elif event.type == pygame.QUIT:
                running = False
            elif event.type == ADDENEMY and spawn_delay_passed:
                new_enemy = Enemy()
                enemies.add(new_enemy)
                all_sprites.add(new_enemy)

        # Process commands from the queue
        while not command_queue.empty():
            command = command_queue.get_nowait()  # Retrieve the next command without blocking
            if command == "shoot":
                if current_shots > 0:
                    killed_enemies = pygame.sprite.spritecollide(player, enemies, dokill=True)
                    if killed_enemies:
                        for _ in killed_enemies:
                            score += 100 * len(killed_enemies)  # Update the score based on the number of enemies killed

        #asyncio.get_event_loop().run_until_complete(asyncio.sleep(0))
        player.update()

        for enemy in enemies:
            enemy.update()
            if enemy.rect.right < 0:  # Enemy has passed the left edge
                health_lost_sound.play()
                enemy.kill()
                player_health -= 10  # Decrease health by 10%

        # Check player health after updating all enemies
        if player_health <= 0:
            game_over_screen(score)  # Call game over screen when health depletes
            break  # Exit the game loop

        screen.blit(background, (0, 0))
        draw_health_bar(screen, player_health, HEALTH_BAR_POSITION)
        for entity in all_sprites:
            screen.blit(entity.surf, entity.rect)

        draw_text("WALL HEALTH", (HEALTH_BAR_POSITION[0], HEALTH_BAR_POSITION[1] - 40), font_size=60)
        mag_text = f"ENERGY BLASTS: {current_shots}/{max_shots}"
        draw_text(mag_text, (SCREEN_WIDTH - 220, SCREEN_HEIGHT - 30), font_size=30)
        draw_text(f"SCORE: {score}", (SCREEN_WIDTH * 0.5, SCREEN_HEIGHT * 0.05), font_size=80)

        pygame.display.flip()
        clock.tick(30)

def draw_health_bar(screen, health, position):
    # Define the position and size of the health bar
    health_bar_x = position[0] - (HEALTH_BAR_WIDTH // 2)
    health_bar_y = position[1]
    health_bar_filled_width = int((health / max_player_health) * HEALTH_BAR_WIDTH)

    # Draw the health bar outline
    outline_rect = pygame.Rect(health_bar_x, health_bar_y, HEALTH_BAR_WIDTH, HEALTH_BAR_HEIGHT)
    pygame.draw.rect(screen, HEALTH_BAR_OUTLINE_COLOR, outline_rect, HEALTH_BAR_OUTLINE_WIDTH)

    # Draw the filled part of the health bar
    filled_rect = pygame.Rect(health_bar_x, health_bar_y, health_bar_filled_width, HEALTH_BAR_HEIGHT)
    pygame.draw.rect(screen, (255, 0, 0), filled_rect)

def game_over_screen(score):
    recognizer = sr.Recognizer()
    microphone = sr.Microphone()

    while True:  # Using 'True' for clarity
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    game_loop(restart=True)  # Restart the game
                    return  # Exit the game over screen after restarting the game
                elif event.key == pygame.K_ESCAPE:
                    main_menu()  # Return to the main menu
                    return  # Exit the game over screen after going to the main menu
            elif event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        screen.fill((0, 0, 0))  # Clear the screen
        draw_text("GAME OVER", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 8), font_size=120, color=(255, 0, 0))
        draw_text(f"YOUR SCORE: {score}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 4), font_size=120)
        #draw_text("PLAY AGAIN", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.3), font_size=80)
        draw_text("RETURN", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2), font_size=80)

        pygame.display.flip()  # Update the screen
        clock.tick(30)  # Maintain a steady framerate


def main_menu():
    global switch_to_settings
    global menu_running

    menu_running = True
    switch_to_settings = False

    # Load and scale the main menu background image
    main_menu_background = pygame.image.load("main_menu_background.png").convert()
    main_menu_background = pygame.transform.scale(main_menu_background, (SCREEN_WIDTH, SCREEN_HEIGHT))

    # Load and play background music
    pygame.mixer.music.load('main_menu_music.mp3')
    pygame.mixer.music.play(-1)  # Play the music indefinitely

    while menu_running:
        # Increment the counter
        command_check_counter += 1

        # Event handling and drawing code for the main menu
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    pygame.mixer.music.stop()  # Stop music before starting the game
                    game_loop()  # Start the game
                    pygame.mixer.music.play(-1)  # Resume music when returning to the main menu
                elif event.key == pygame.K_s:
                    settings_menu()  # Go to settings, music continues
                elif event.key == pygame.K_ESCAPE:
                    menu_running = False  # Quitting the main menu
                    pygame.quit()
                    os._exit(0)
            elif event.type == pygame.QUIT:
                menu_running = False

        # Clear the screen and draw the background and menu items
        screen.blit(main_menu_background, (0, 0))
        draw_text("RAILGUN RAMPAGE", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 14), font_size=140)
        draw_text("PLAY", (SCREEN_WIDTH/2, SCREEN_HEIGHT/2.7), font_size=80)
        draw_text("SETTINGS", (SCREEN_WIDTH/2, SCREEN_HEIGHT/2.3), font_size=80)
        draw_text("QUIT", (SCREEN_WIDTH/2, SCREEN_HEIGHT/2), font_size=80)

        pygame.display.flip()  # Update the display
        clock.tick(30)  # Limit the frame rate

if __name__ == '__main__':
    main_menu()

# Release the camera when the game is closed
cap.release()
cv2.destroyAllWindows()